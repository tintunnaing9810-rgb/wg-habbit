import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Legacy (keep for compat)
        ink: "#0d1b2a",
        mist: "#e0eaf3",
        surf: "#5fa8d3",
        tide: "#0f4c5c",
        gold: "#F4A261",
        sand: "#f7f1e6",
        coral: "#E63946",
        parchment: "#f0e3c0",
        wood: "#5a3515",
        // New design system
        ocean:   "#1D3557",
        surface: "#111111",
        pirate:  "#E63946",
        treasure:"#F4A261",
        softwhite: "#F1FAEE",
        // Journey tiers
        "tier-beginner":     "#2A9D8F",
        "tier-intermediate": "#E9C46A",
        "tier-advanced":     "#9D4EDD",
        "tier-elite":        "#D00000",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      borderRadius: {
        btn: "4px",
      },
      boxShadow: {
        card: "0 18px 50px rgba(0,0,0,0.4)",
        "gold-glow":    "0 0 24px rgba(244,162,97,0.35)",
        "gold-glow-lg": "0 0 40px rgba(244,162,97,0.5)",
        "dark-lg":      "0 24px 64px rgba(0,0,0,0.7)",
        "pirate-glow":  "0 0 20px rgba(230,57,70,0.4)",
        "tier-glow":    "0 0 16px var(--journey-color, #2A9D8F)",
      },
      keyframes: {
        float:       { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-10px)" } },
        twinkle:     { "0%,100%": { opacity: "0.2", transform: "scale(0.8)" }, "50%": { opacity: "1", transform: "scale(1.3)" } },
        popIn:       { "0%": { opacity: "0", transform: "scale(0.85) translateY(16px)" }, "100%": { opacity: "1", transform: "scale(1) translateY(0)" } },
        fadeIn:      { from: { opacity: "0" }, to: { opacity: "1" } },
        goldGlow:    { "0%,100%": { boxShadow: "0 0 20px rgba(244,162,97,0.25)" }, "50%": { boxShadow: "0 0 40px rgba(244,162,97,0.55)" } },
        shimmer:     { "0%": { backgroundPosition: "-200% center" }, "100%": { backgroundPosition: "200% center" } },
        fadeSlideUp: { from: { opacity: "0", transform: "translateY(14px)" }, to: { opacity: "1", transform: "translateY(0)" } },
        blink:       { "0%,100%": { opacity: "1" }, "50%": { opacity: "0.15" } },
        spinSlow:    { from: { transform: "rotate(0deg)" }, to: { transform: "rotate(360deg)" } },
        waveFloat:   { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-4px)" } },
        redPulse:    { "0%": { boxShadow: "inset 0 0 0 0 rgba(230,57,70,0)" }, "40%": { boxShadow: "inset 0 0 80px 0 rgba(230,57,70,0.35)" }, "100%": { boxShadow: "inset 0 0 0 0 rgba(230,57,70,0)" } },
        btnPulse:    { "0%": { transform: "scale(1)" }, "50%": { transform: "scale(0.95)" }, "100%": { transform: "scale(1)" } },
        tierGlow:    { "0%,100%": { boxShadow: "0 0 8px var(--journey-color, #2A9D8F)" }, "50%": { boxShadow: "0 0 20px var(--journey-color, #2A9D8F)" } },
      },
      animation: {
        float:          "float 3s ease-in-out infinite",
        twinkle:        "twinkle 2s ease-in-out infinite",
        "pop-in":       "popIn 0.45s cubic-bezier(0.34,1.56,0.64,1) forwards",
        "fade-in":      "fadeIn 0.3s ease-out forwards",
        "gold-glow":    "goldGlow 2.5s ease-in-out infinite",
        shimmer:        "shimmer 4s linear infinite",
        "fade-slide-up":"fadeSlideUp 0.4s ease-out forwards",
        blink:          "blink 1.5s ease-in-out infinite",
        "spin-slow":    "spinSlow 12s linear infinite",
        "wave-float":   "waveFloat 4s ease-in-out infinite",
        "red-pulse":    "redPulse 0.6s ease-out forwards",
        "btn-pulse":    "btnPulse 0.2s ease-out",
        "tier-glow":    "tierGlow 2s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};

export default config;
