create extension if not exists "pgcrypto";

create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null unique,
  total_points integer not null default 0,
  avatar_url text,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.activities (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  activity_type text not null,
  distance_km double precision,
  duration_min integer,
  reps integer,
  points integer not null default 0,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.milestones (
  id integer primary key,
  name text not null,
  points_required integer not null unique,
  title text not null
);

insert into public.milestones (id, name, points_required, title)
values
  (1, 'East Blue Rookie', 0, 'Foosha Village'),
  (2, 'Grand Line Scout', 100, 'Reverse Mountain'),
  (3, 'Straw Hat Ally', 200, 'Alabasta'),
  (4, 'Going Merry Keeper', 300, 'Water 7'),
  (5, 'Thousand Sunny Captain', 500, 'Sabaody'),
  (6, 'Yonko Challenger', 700, 'Wano'),
  (7, 'Pirate King Contender', 1000, 'Laugh Tale')
on conflict (id) do update
set
  name = excluded.name,
  points_required = excluded.points_required,
  title = excluded.title;

alter table public.users enable row level security;
alter table public.activities enable row level security;
alter table public.milestones enable row level security;

drop policy if exists "Users can view all profiles for leaderboard" on public.users;
create policy "Users can view all profiles for leaderboard"
on public.users
for select
to authenticated
using (true);

drop policy if exists "Users can update own profile" on public.users;
create policy "Users can update own profile"
on public.users
for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

drop policy if exists "Users can read own activities" on public.activities;
create policy "Users can read own activities"
on public.activities
for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can insert own activities" on public.activities;
create policy "Users can insert own activities"
on public.activities
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Authenticated users can view milestones" on public.milestones;
create policy "Authenticated users can view milestones"
on public.milestones
for select
to authenticated
using (true);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (id, name, email)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'name', split_part(new.email, '@', 1)),
    new.email
  )
  on conflict (id) do update
  set
    name = excluded.name,
    email = excluded.email;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.calculate_activity_points(
  p_activity_type text,
  p_distance_km double precision default null,
  p_duration_min integer default null,
  p_reps integer default null
)
returns integer
language plpgsql
immutable
as $$
declare
  normalized_type text := lower(trim(p_activity_type));
begin
  return case normalized_type
    when 'running'     then round((coalesce(p_distance_km, 0) * 5.5)::numeric)::integer
    when 'walking'     then round((coalesce(p_distance_km, 0) * 3)::numeric)::integer
    when 'swimming'    then round((coalesce(p_duration_min, 0) * 0.8)::numeric)::integer
    when 'gym'         then round((coalesce(p_duration_min, 0) * 0.8)::numeric)::integer
    when 'muay thai'   then round((coalesce(p_duration_min, 0) * 0.8)::numeric)::integer
    when 'futsal'      then round((coalesce(p_duration_min, 0) * 0.8)::numeric)::integer
    when 'football'    then round((coalesce(p_duration_min, 0) * 0.8)::numeric)::integer
    when 'badminton'   then round((coalesce(p_duration_min, 0) * 0.8)::numeric)::integer
    when 'plank'       then round((coalesce(p_duration_min, 0) * 1.0)::numeric)::integer
    when 'push-ups'    then round((coalesce(p_reps, 0) * 0.4)::numeric)::integer
    when 'pull ups'    then round((coalesce(p_reps, 0) * 0.5)::numeric)::integer
    when 'sit ups'     then round((coalesce(p_reps, 0) * 0.2)::numeric)::integer
    when 'abs workout' then round((coalesce(p_reps, 0) * 0.4)::numeric)::integer
    when 'male kegel'  then round((coalesce(p_reps, 0) * 0.2)::numeric)::integer
    when 'golf'        then round((coalesce(p_duration_min, 0) * 0.3)::numeric)::integer
    when '3l water'    then 5
    when 'stretch'     then 5
    else 0
  end;
end;
$$;

create or replace function public.log_activity(
  p_user_id uuid,
  p_activity_type text,
  p_distance_km double precision default null,
  p_duration_min integer default null,
  p_reps integer default null
)
returns table (
  activity_id uuid,
  awarded_points integer,
  new_total_points integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  calculated_points integer;
  created_activity_id uuid;
  updated_total integer;
begin
  if auth.uid() is distinct from p_user_id then
    raise exception 'You can only log activities for yourself.';
  end if;

  calculated_points := public.calculate_activity_points(
    p_activity_type,
    p_distance_km,
    p_duration_min,
    p_reps
  );

  if calculated_points <= 0 then
    raise exception 'Calculated points must be greater than zero.';
  end if;

  insert into public.activities (
    user_id,
    activity_type,
    distance_km,
    duration_min,
    reps,
    points
  )
  values (
    p_user_id,
    p_activity_type,
    p_distance_km,
    p_duration_min,
    p_reps,
    calculated_points
  )
  returning id into created_activity_id;

  update public.users
  set total_points = total_points + calculated_points
  where id = p_user_id
  returning total_points into updated_total;

  return query
  select created_activity_id, calculated_points, updated_total;
end;
$$;
