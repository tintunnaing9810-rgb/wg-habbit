import { cn } from "@/lib/utils";
import type { StoryMilestone } from "@/lib/progression";
import { formatPoints } from "@/lib/utils";

type IslandMapProps = { milestones: StoryMilestone[]; totalPoints: number };

export function IslandMap({ milestones, totalPoints }: IslandMapProps) {
  return (
    <div className="relative">
      {milestones.map((milestone, index) => {
        const unlocked = totalPoints >= milestone.min;
        const isCurrent = totalPoints >= milestone.min && totalPoints < milestone.max;
        const isLast = index === milestones.length - 1;

        return (
          <div key={milestone.id} className="relative flex gap-4">
            <div className="flex flex-col items-center">
              <div
                className={cn("relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 text-xs font-black transition-all")}
                style={{
                  borderColor: isCurrent ? "#E63946" : unlocked ? "#F4A261" : "rgba(241,250,238,0.1)",
                  background:  isCurrent ? "#E63946" : unlocked ? "rgba(244,162,97,0.15)" : "rgba(241,250,238,0.03)",
                  color:       isCurrent ? "#F1FAEE"  : unlocked ? "#F4A261" : "rgba(241,250,238,0.2)",
                }}
              >
                {isCurrent ? "✦" : unlocked ? "✓" : index + 1}
              </div>
              {!isLast && (
                <div className="mt-1 w-0.5 flex-1" style={{ minHeight: "1.5rem", background: unlocked ? "rgba(244,162,97,0.3)" : "rgba(241,250,238,0.05)" }} />
              )}
            </div>
            <div
              className="mb-3 flex-1 rounded-[8px] border p-4 transition-all"
              style={{
                borderColor: isCurrent ? "rgba(230,57,70,0.3)" : unlocked ? "rgba(244,162,97,0.15)" : "rgba(241,250,238,0.05)",
                background:  isCurrent ? "rgba(230,57,70,0.08)" : "rgba(241,250,238,0.03)",
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="label-caps" style={{ color: isCurrent ? "rgba(230,57,70,0.7)" : "rgba(241,250,238,0.25)" }}>{milestone.arc}</p>
                  <h3 className="mt-0.5 text-sm font-bold" style={{ color: isCurrent ? "#F1FAEE" : unlocked ? "rgba(241,250,238,0.65)" : "rgba(241,250,238,0.2)" }}>
                    {milestone.title}
                  </h3>
                  {isCurrent && <p className="mt-2 text-xs leading-5" style={{ color: "rgba(241,250,238,0.5)" }}>{milestone.message}</p>}
                </div>
                <span className="shrink-0 rounded-[4px] px-2 py-1 text-[10px] font-bold" style={{ background: isCurrent ? "rgba(230,57,70,0.15)" : "rgba(241,250,238,0.05)", color: isCurrent ? "#E63946" : "rgba(241,250,238,0.25)" }}>
                  {formatPoints(milestone.min)}-{formatPoints(milestone.max)}
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
