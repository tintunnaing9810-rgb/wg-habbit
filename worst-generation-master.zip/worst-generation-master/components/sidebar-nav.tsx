"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Compass, History, Map, ScrollText, Trophy } from "lucide-react";

const navItems = [
  { href: "/dashboard",  label: "Dashboard",    icon: Compass,     sub: "Grand Line HQ" },
  { href: "/log",        label: "Ship's Log",   icon: ScrollText,  sub: "Record activity" },
  { href: "/history",    label: "My Record",    icon: History,     sub: "Full history" },
  { href: "/leaderboard", label: "Bounty Board", icon: Trophy,    sub: "Crew standings" },
  { href: "/progress",   label: "Treasure Map", icon: Map,         sub: "Your journey" },
];

export function SidebarNav() {
  const pathname = usePathname();
  return (
    <nav className="grid gap-1">
      {navItems.map((item) => {
        const Icon = item.icon;
        const active = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className="flex items-center gap-3 rounded-[8px] px-4 py-3 transition-all"
            style={{
              background:   active ? "rgba(230,57,70,0.12)" : "transparent",
              border:       active ? "1px solid rgba(230,57,70,0.35)" : "1px solid transparent",
              color:        active ? "#E63946" : "rgba(241,250,238,0.55)",
            }}
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[6px] transition-all"
              style={{ background: active ? "rgba(230,57,70,0.2)" : "rgba(241,250,238,0.06)", color: active ? "#E63946" : "rgba(241,250,238,0.4)" }}>
              <Icon className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <p className="font-semibold text-sm leading-none" style={{ color: active ? "#E63946" : "#F1FAEE" }}>{item.label}</p>
              <p className="mt-1 truncate text-[11px]" style={{ color: active ? "rgba(230,57,70,0.6)" : "rgba(241,250,238,0.3)" }}>{item.sub}</p>
            </div>
          </Link>
        );
      })}
    </nav>
  );
}
