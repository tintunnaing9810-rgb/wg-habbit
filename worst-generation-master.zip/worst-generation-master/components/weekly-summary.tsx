"use client";

import { useEffect, useState } from "react";

type Activity = {
  activity_type: string;
  points: number;
  distance_km: number | null;
  duration_min: number | null;
  reps: number | null;
};

type Stats = {
  totalPoints: number;
  totalSessions: number;
  runKm: number;
  walkKm: number;
  gymMin: number;
  muayThaiMin: number;
  footballMin: number;
  badmintonMin: number;
  repsTotal: number;
};

function buildStats(activities: Activity[]): Stats {
  return activities.reduce<Stats>(
    (acc, a) => {
      acc.totalPoints   += a.points;
      acc.totalSessions += 1;
      const type = a.activity_type.toLowerCase();
      if (type === "running")      acc.runKm        += a.distance_km  ?? 0;
      if (type === "walking")      acc.walkKm       += a.distance_km  ?? 0;
      if (type === "gym")          acc.gymMin        += a.duration_min ?? 0;
      if (type === "muay thai")    acc.muayThaiMin   += a.duration_min ?? 0;
      if (type === "football")     acc.footballMin   += a.duration_min ?? 0;
      if (type === "badminton")    acc.badmintonMin  += a.duration_min ?? 0;
      if (["push-ups","pull ups","sit ups","abs workout"].includes(type))
                                   acc.repsTotal     += a.reps ?? 0;
      return acc;
    },
    { totalPoints: 0, totalSessions: 0, runKm: 0, walkKm: 0, gymMin: 0, muayThaiMin: 0, footballMin: 0, badmintonMin: 0, repsTotal: 0 },
  );
}

export function WeeklySummary() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/weekly-summary", { cache: "no-store" })
      .then(r => r.json())
      .then(d => setStats(buildStats(d.activities ?? [])));
  }, []);

  const rows: { label: string; value: string; icon: string }[] = [];
  if (stats) {
    if (stats.runKm      > 0) rows.push({ icon: "🏃", label: "Running",   value: `${stats.runKm.toFixed(1)} km` });
    if (stats.walkKm     > 0) rows.push({ icon: "🚶", label: "Walking",   value: `${stats.walkKm.toFixed(1)} km` });
    if (stats.gymMin     > 0) rows.push({ icon: "💪", label: "Gym",       value: `${stats.gymMin} min` });
    if (stats.muayThaiMin > 0) rows.push({ icon: "🥊", label: "Muay Thai", value: `${stats.muayThaiMin} min` });
    if (stats.footballMin > 0) rows.push({ icon: "⚽", label: "Football",  value: `${stats.footballMin} min` });
    if (stats.badmintonMin > 0) rows.push({ icon: "🏸", label: "Badminton", value: `${stats.badmintonMin} min` });
    if (stats.repsTotal  > 0) rows.push({ icon: "🔁", label: "Reps",      value: `${stats.repsTotal} total` });
  }

  return (
    <section className="rounded-[12px] p-5" style={{ background: "#111111", border: "1px solid rgba(241,250,238,0.08)" }}>
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="label-caps">This Week</p>
          <h2 className="mt-0.5 text-base font-black uppercase tracking-[0.06em]" style={{ color: "#F1FAEE" }}>
            Weekly Summary
          </h2>
        </div>
        {stats && (
          <div className="text-right">
            <p className="text-2xl font-black leading-none" style={{ color: "#F4A261" }}>
              +{stats.totalPoints}
            </p>
            <p className="text-[10px] mt-0.5" style={{ color: "rgba(241,250,238,0.3)" }}>pts this week</p>
          </div>
        )}
      </div>

      {!stats ? (
        <div className="space-y-2">
          {[1, 2, 3].map(i => <div key={i} className="h-8 animate-pulse rounded-[6px]" style={{ background: "rgba(241,250,238,0.04)" }} />)}
        </div>
      ) : stats.totalSessions === 0 ? (
        <div className="text-center py-6">
          <p className="text-2xl">⚓</p>
          <p className="mt-2 text-xs" style={{ color: "rgba(241,250,238,0.3)" }}>No sessions logged this week yet.</p>
        </div>
      ) : (
        <>
          {/* Session count bar */}
          <div className="flex items-center gap-3 mb-3 rounded-[6px] px-3 py-2"
            style={{ background: "rgba(244,162,97,0.07)", border: "1px solid rgba(244,162,97,0.15)" }}>
            <span className="text-lg">📅</span>
            <p className="text-sm font-bold" style={{ color: "#F4A261" }}>
              {stats.totalSessions} {stats.totalSessions === 1 ? "session" : "sessions"} this week
            </p>
          </div>

          {/* Activity breakdown */}
          <div className="space-y-1.5">
            {rows.map(row => (
              <div key={row.label} className="flex items-center justify-between rounded-[6px] px-3 py-2"
                style={{ background: "rgba(241,250,238,0.03)", border: "1px solid rgba(241,250,238,0.06)" }}>
                <div className="flex items-center gap-2">
                  <span className="text-sm">{row.icon}</span>
                  <span className="text-xs font-semibold" style={{ color: "rgba(241,250,238,0.6)" }}>{row.label}</span>
                </div>
                <span className="text-xs font-black" style={{ color: "#F1FAEE" }}>{row.value}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}
