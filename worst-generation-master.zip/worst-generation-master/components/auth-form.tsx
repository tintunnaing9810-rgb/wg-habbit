"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Anchor, LoaderCircle } from "lucide-react";
import { FormEvent, useState } from "react";

import { createClient } from "@/lib/supabase/client";

type AuthFormProps = { mode: "login" | "signup" };

const inputStyle: React.CSSProperties = {
  width: "100%",
  background: "rgba(241,250,238,0.05)",
  border: "1px solid rgba(241,250,238,0.12)",
  borderRadius: 4,
  padding: "12px 16px",
  fontSize: 14,
  color: "#F1FAEE",
  outline: "none",
  transition: "border-color 0.2s",
  fontFamily: "Inter, system-ui, sans-serif",
};

export function AuthForm({ mode }: AuthFormProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();
  const [error, setError]   = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const searchError = searchParams.get("error");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true); setError(null); setNotice(null);

    const formData = new FormData(event.currentTarget);
    const email    = String(formData.get("email") ?? "");
    const password = String(formData.get("password") ?? "");
    const name     = String(formData.get("name") ?? "");

    if (mode === "signup") {
      const { data, error: signupError } = await supabase.auth.signUp({
        email, password,
        options: { emailRedirectTo: `${window.location.origin}/auth/confirm?next=/dashboard`, data: { name } },
      });
      if (signupError) { setError(signupError.message); setPending(false); return; }
      if (!data.session) { setNotice("Account created. Check your email to confirm before logging in."); setPending(false); return; }
    } else {
      const { error: loginError } = await supabase.auth.signInWithPassword({ email, password });
      if (loginError) { setError(loginError.message); setPending(false); return; }
    }

    router.push("/dashboard");
    router.refresh();
  }

  return (
    <div className="w-full rounded-[12px] p-8" style={{ background: "#111111", border: "1px solid rgba(230,57,70,0.25)" }}>
      {/* Header */}
      <div className="text-center mb-8">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-[8px]" style={{ background: "rgba(230,57,70,0.15)" }}>
          <Anchor className="h-7 w-7" style={{ color: "#E63946" }} />
        </div>
        <h1 className="text-2xl font-black uppercase tracking-[0.1em]" style={{ color: "#F1FAEE" }}>Worst Generation</h1>
        <p className="mt-1 text-sm" style={{ color: "rgba(241,250,238,0.4)" }}>
          {mode === "signup" ? "Register your bounty profile" : "Return to the Grand Line"}
        </p>
      </div>

      <form className="grid gap-4" onSubmit={handleSubmit}>
        {mode === "signup" && (
          <div className="grid gap-1.5">
            <label className="label-caps">Pirate Name</label>
            <input name="name" required placeholder="Monkey D. Luffy" style={inputStyle} />
          </div>
        )}
        <div className="grid gap-1.5">
          <label className="label-caps">Email</label>
          <input name="email" type="email" required placeholder="captain@grandline.sea" style={inputStyle} />
        </div>
        <div className="grid gap-1.5">
          <label className="label-caps">Password</label>
          <input name="password" type="password" required minLength={6} placeholder="At least 6 characters" style={inputStyle} />
        </div>

        {(error || searchError) && (
          <p className="rounded-[4px] px-4 py-3 text-xs" style={{ background: "rgba(230,57,70,0.12)", color: "#E63946", border: "1px solid rgba(230,57,70,0.25)" }}>
            {error ?? searchError}
          </p>
        )}
        {notice && (
          <p className="rounded-[4px] px-4 py-3 text-xs" style={{ background: "rgba(244,162,97,0.1)", color: "#F4A261", border: "1px solid rgba(244,162,97,0.25)" }}>
            {notice}
          </p>
        )}

        <button type="submit" disabled={pending} className="btn-primary w-full mt-2">
          {pending && <LoaderCircle className="h-4 w-4 animate-spin" />}
          {pending ? "Navigating..." : mode === "signup" ? "⚡ Set Sail — Create Account" : "⚓ Return to the Grand Line"}
        </button>
      </form>

      <p className="mt-6 text-center text-xs" style={{ color: "rgba(241,250,238,0.4)" }}>
        {mode === "signup" ? "Already sailing?" : "Need a bounty profile?"}{" "}
        <Link href={mode === "signup" ? "/login" : "/signup"} className="font-bold" style={{ color: "#E63946" }}>
          {mode === "signup" ? "Log in" : "Sign up"}
        </Link>
      </p>
    </div>
  );
}
