"use client";

import { useEffect, useState } from "react";
import { Anchor, Ship, Star, X } from "lucide-react";

import type { StoryMonth } from "@/lib/progression";

type ChapterUnlockPopupProps = {
  month: StoryMonth;
  onDismiss: () => void;
};

const STAR_POSITIONS = [
  { top: "-1.25rem", left: "12%", delay: "0s", duration: "1.8s" },
  { top: "-0.75rem", right: "18%", delay: "0.4s", duration: "2.2s" },
  { top: "20%", left: "-1.25rem", delay: "0.8s", duration: "1.6s" },
  { top: "15%", right: "-1rem", delay: "0.2s", duration: "2s" },
  { bottom: "22%", left: "-1rem", delay: "1s", duration: "1.9s" },
  { bottom: "18%", right: "-1.25rem", delay: "0.6s", duration: "2.1s" },
  { bottom: "-0.75rem", left: "30%", delay: "0.3s", duration: "1.7s" },
  { bottom: "-1rem", right: "28%", delay: "0.9s", duration: "2.3s" },
];

const MONTH_SUBTITLES: Record<number, string> = {
  2: "The sands shift beneath your boots. New dangers, new allies, and a desert full of secrets await beyond the horizon.",
  3: "The sky stretches endlessly above. Between clouds and lightning, your greatest test of belief begins.",
};

export function ChapterUnlockPopup({ month, onDismiss }: ChapterUnlockPopupProps) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setShow(true), 40);
    return () => clearTimeout(t);
  }, []);

  function handleDismiss() {
    setShow(false);
    setTimeout(onDismiss, 350);
  }

  const subtitle = MONTH_SUBTITLES[month.id] ?? "A new chapter of your journey has been unlocked. Sail forward.";

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 transition-all duration-300 ${
        show ? "bg-ink/65 backdrop-blur-sm" : "bg-transparent backdrop-blur-none"
      }`}
      onClick={handleDismiss}
    >
      <div
        className={`relative w-full max-w-sm transition-all duration-300 ${
          show ? "animate-pop-in" : "opacity-0 scale-90"
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Twinkling stars around the card */}
        {STAR_POSITIONS.map((pos, i) => (
          <Star
            key={i}
            className="absolute h-4 w-4 fill-gold text-gold"
            style={{
              ...pos,
              animation: `twinkle ${pos.duration} ease-in-out ${pos.delay} infinite`,
            }}
          />
        ))}

        {/* Main card */}
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-b from-[#0d1b2a] via-[#0f2d3d] to-[#0f4c5c] p-8 text-white shadow-[0_0_80px_rgba(216,164,55,0.25),0_32px_64px_rgba(13,27,42,0.6)]">
          {/* Gold shimmer top border */}
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/60 to-transparent" />

          {/* Dismiss button */}
          <button
            onClick={handleDismiss}
            className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white/50 transition hover:bg-white/20 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>

          {/* Anchor decoration */}
          <div className="absolute bottom-4 right-5 opacity-5">
            <Anchor className="h-28 w-28 text-white" />
          </div>

          {/* Animated ship icon */}
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-gold/20 ring-4 ring-gold/30 animate-float">
            <Ship className="h-10 w-10 text-gold" />
          </div>

          {/* Text content */}
          <div className="relative text-center">
            <p className="text-[0.65rem] font-bold uppercase tracking-[0.25em] text-gold/70">
              New Chapter Unlocked
            </p>
            <h2 className="mt-3 text-2xl font-bold leading-tight tracking-wide text-white">
              {month.title}
            </h2>
            <div className="mx-auto mt-3 h-px w-16 bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
            <p className="mt-4 text-sm leading-relaxed text-white/60">{subtitle}</p>
          </div>

          {/* CTA button */}
          <button
            onClick={handleDismiss}
            className="relative mt-8 w-full rounded-2xl bg-gradient-to-r from-gold to-[#c8941f] px-6 py-4 font-bold text-ink shadow-[0_4px_20px_rgba(216,164,55,0.4)] transition hover:shadow-[0_4px_28px_rgba(216,164,55,0.6)] hover:brightness-110 active:scale-[0.98]"
          >
            Set Sail! &rarr;
          </button>
        </div>
      </div>
    </div>
  );
}
