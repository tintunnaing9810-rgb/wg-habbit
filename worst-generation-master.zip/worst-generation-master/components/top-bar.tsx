import { Anchor } from "lucide-react";
import Link from "next/link";

import { HamburgerMenu } from "@/components/hamburger-menu";
import { createClient } from "@/lib/supabase/server";

export async function TopBar() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: profileRaw } = user
    ? await supabase.from("users").select("name, total_points, avatar_url").eq("id", user.id).single()
    : { data: null };

  const profile = profileRaw as { name: string; total_points: number; avatar_url: string | null } | null;

  return (
    <header
      className="fixed inset-x-0 top-0 z-30 flex items-center justify-between px-5 py-3"
      style={{
        background: "rgba(17,17,17,0.96)",
        borderBottom: "1px solid rgba(230,57,70,0.2)",
        backdropFilter: "blur(12px)",
      }}
    >
      <Link href="/dashboard" className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-[8px]" style={{ background: "rgba(230,57,70,0.15)" }}>
          <Anchor className="h-5 w-5" style={{ color: "#E63946" }} />
        </div>
        <span className="text-base font-black uppercase tracking-[0.15em]" style={{ color: "#F1FAEE" }}>
          Worst Generation
        </span>
      </Link>

      {profile && user ? (
        <HamburgerMenu userName={profile.name} totalPoints={profile.total_points} userId={user.id} avatarUrl={profile.avatar_url} />
      ) : null}
    </header>
  );
}
