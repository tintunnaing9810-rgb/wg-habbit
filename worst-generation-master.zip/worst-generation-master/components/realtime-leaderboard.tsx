"use client";

import { useEffect, useState } from "react";

import { LeaderboardTable } from "@/components/leaderboard-table";
import { createClient } from "@/lib/supabase/client";
import { getCurrentMilestone, type UserProfile } from "@/lib/progression";
import { getStreakColor, getStreakEmoji } from "@/lib/streak";
import { getJourneyLabel, getJourneyColor } from "@/lib/journey";
import { formatPoints } from "@/lib/utils";

type WeeklyUser = UserProfile & { weekly_points: number };
type RealtimeLeaderboardProps = { initialUsers: UserProfile[] };

const TOP_META = [
  { rank: "1ST", color: "#F4A261", bg: "rgba(244,162,97,0.08)", border: "rgba(244,162,97,0.35)", order: "order-2", scale: true },
  { rank: "2ND", color: "#c0c0c0", bg: "rgba(192,192,192,0.06)", border: "rgba(192,192,192,0.25)", order: "order-1", scale: false },
  { rank: "3RD", color: "#cd7f32", bg: "rgba(205,127,50,0.06)", border: "rgba(205,127,50,0.25)", order: "order-3", scale: false },
];

function TopCard({ user, meta, points }: { user: UserProfile; meta: typeof TOP_META[0]; points: number }) {
  const milestone    = getCurrentMilestone(user.total_points);
  const journeyLabel = getJourneyLabel(user.total_points);
  const journeyColor = getJourneyColor(user.total_points);
  const streak       = (user as Record<string, unknown>).streak_count as number ?? 0;
  const status       = (user as Record<string, unknown>).streak_status as string ?? "active";
  const streakColor  = getStreakColor(status);
  const streakEmoji  = getStreakEmoji(status);
  const avatarUrl    = (user as Record<string, unknown>).avatar_url as string | null;

  return (
    <div className={`flex flex-col items-center ${meta.order} flex-1`} style={{ maxWidth: meta.scale ? 140 : 120 }}>
      <p className="text-[10px] font-black uppercase tracking-[0.2em] mb-1.5" style={{ color: meta.color }}>
        {meta.rank}
      </p>
      <div className="w-full rounded-[10px] overflow-hidden" style={{ background: meta.bg, border: `1px solid ${meta.border}`, paddingBottom: 10 }}>
        <div className="text-center py-1 mb-2" style={{ background: `${meta.color}15`, borderBottom: `1px solid ${meta.border}` }}>
          <p className="font-black uppercase tracking-widest" style={{ fontSize: 8, color: meta.color, letterSpacing: "0.2em" }}>WANTED</p>
        </div>

        <div className="mx-auto mb-2 overflow-hidden rounded-sm"
          style={{ width: meta.scale ? 72 : 60, height: meta.scale ? 72 : 60, border: `2px solid ${meta.color}`, boxShadow: `0 0 10px ${meta.color}30` }}>
          {avatarUrl ? (
            <img src={avatarUrl} alt={user.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          ) : (
            <div className="w-full h-full flex items-center justify-center" style={{ background: `${meta.color}15` }}>
              <span className="font-black" style={{ color: meta.color, fontSize: meta.scale ? 24 : 20 }}>
                {user.name?.charAt(0)?.toUpperCase() ?? "?"}
              </span>
            </div>
          )}
        </div>

        <div className="text-center px-1 pb-1 mb-1" style={{ borderBottom: `1px solid ${meta.border}` }}>
          <p className="font-black uppercase leading-tight"
            style={{ color: "#F1FAEE", fontSize: meta.scale ? 11 : 10, wordBreak: "break-word", lineHeight: 1.3 }}>
            {user.name}
          </p>
        </div>

        <div className="text-center px-1 pt-1">
          <p className="font-black leading-none" style={{ color: meta.color, fontSize: meta.scale ? 18 : 15 }}>
            ฿{formatPoints(points)}
          </p>
          <p style={{ fontSize: 7, color: "rgba(241,250,238,0.3)", marginTop: 1 }}>berries</p>
        </div>

        <div className="flex items-center justify-center gap-1 mt-2 mx-2 rounded-[4px] py-1"
          style={{ background: `${streakColor}12`, border: `1px solid ${streakColor}25` }}>
          <span style={{ fontSize: 10 }}>{streakEmoji}</span>
          <span style={{ fontSize: 10, fontWeight: 900, color: streakColor }}>{streak}d</span>
        </div>

        <div className="text-center mt-2 px-1">
          <span className="inline-block font-black uppercase rounded-[2px] px-1.5 py-0.5"
            style={{ fontSize: 7, background: `${journeyColor}18`, color: journeyColor, border: `1px solid ${journeyColor}40`, letterSpacing: "0.05em" }}>
            {journeyLabel}
          </span>
        </div>
      </div>
    </div>
  );
}

export function RealtimeLeaderboard({ initialUsers }: RealtimeLeaderboardProps) {
  const [tab, setTab]           = useState<"alltime" | "weekly">("alltime");
  const [allUsers, setAllUsers] = useState(initialUsers);
  const [weekUsers, setWeekUsers] = useState<WeeklyUser[]>([]);
  const [weekLoading, setWeekLoading] = useState(false);

  async function fetchWeekly() {
    setWeekLoading(true);
    const res = await fetch("/api/leaderboard/weekly", { cache: "no-store" });
    const result = await res.json();
    setWeekUsers(result.users ?? []);
    setWeekLoading(false);
  }

  useEffect(() => {
    const supabase = createClient();
    const channel = supabase
      .channel("leaderboard-updates")
      .on("postgres_changes", { event: "*", schema: "public", table: "users" }, async () => {
        const res = await fetch("/api/leaderboard", { cache: "no-store" });
        const result = await res.json();
        setAllUsers(result.users ?? []);
        if (tab === "weekly") fetchWeekly();
      })
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [tab]);

  useEffect(() => {
    if (tab === "weekly" && weekUsers.length === 0) fetchWeekly();
  }, [tab]);

  const displayUsers  = tab === "alltime" ? allUsers : weekUsers;
  const getPoints     = (u: UserProfile) => tab === "alltime" ? u.total_points : (u as WeeklyUser).weekly_points;
  const top3          = displayUsers.slice(0, 3);
  const rest          = displayUsers.slice(3);

  return (
    <div className="space-y-4">

      {/* Header */}
      <div className="flex items-center justify-between px-1">
        <div>
          <p className="label-caps">Grand Line Rankings</p>
          <h2 className="mt-1 text-xl font-black uppercase tracking-[0.06em]" style={{ color: "#F1FAEE" }}>
            Bounty Board
          </h2>
        </div>
        <div className="flex items-center gap-2 rounded-[4px] px-3 py-1.5 text-xs font-bold"
          style={{ background: "rgba(34,197,94,0.1)", color: "#22c55e", border: "1px solid rgba(34,197,94,0.2)" }}>
          <span className="live-dot" />Live
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-[8px] p-1 gap-1" style={{ background: "rgba(241,250,238,0.05)", border: "1px solid rgba(241,250,238,0.08)" }}>
        {(["alltime", "weekly"] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="flex-1 rounded-[6px] py-2 text-xs font-black uppercase tracking-wider transition-all"
            style={{
              background: tab === t ? "#F4A261" : "transparent",
              color: tab === t ? "#111111" : "rgba(241,250,238,0.4)",
              border: "none", cursor: "pointer",
            }}
          >
            {t === "alltime" ? "⚓ All-Time" : "⚡ This Week"}
          </button>
        ))}
      </div>

      {/* Weekly subtitle */}
      {tab === "weekly" && (
        <p className="text-[11px] px-1" style={{ color: "rgba(241,250,238,0.3)" }}>
          Points earned since Monday — resets every week
        </p>
      )}

      {weekLoading ? (
        <div className="space-y-2">
          {[1,2,3].map(i => <div key={i} className="h-16 animate-pulse rounded-[12px]" style={{ background: "rgba(241,250,238,0.04)" }} />)}
        </div>
      ) : displayUsers.length === 0 ? (
        <div className="rounded-[12px] p-10 text-center" style={{ background: "#111111", border: "1px solid rgba(241,250,238,0.07)" }}>
          <p className="text-4xl">⚓</p>
          <p className="mt-4 text-sm" style={{ color: "rgba(241,250,238,0.35)" }}>
            {tab === "weekly" ? "No activities logged this week yet." : "No pirates on the board yet."}
          </p>
        </div>
      ) : (
        <>
          {/* Top 3 */}
          {top3.length > 0 && (
            <div className="rounded-[12px] p-4" style={{ background: "#111111", border: "1px solid rgba(244,162,97,0.15)" }}>
              <p className="label-caps text-center mb-4" style={{ color: "rgba(244,162,97,0.45)" }}>⚡ Most Wanted ⚡</p>
              <div className="flex items-end justify-center gap-2">
                {TOP_META.map((meta, i) => {
                  const user = top3[i];
                  if (!user) return null;
                  return <TopCard key={user.id} user={user} meta={meta} points={getPoints(user)} />;
                })}
              </div>
            </div>
          )}

          {/* Rest */}
          {rest.length > 0 && (
            <div>
              <p className="label-caps px-1 mb-2">Rest of the Crew</p>
              <LeaderboardTable users={rest} startRank={4} pointsKey={tab === "weekly" ? "weekly_points" : undefined} />
            </div>
          )}
        </>
      )}
    </div>
  );
}
