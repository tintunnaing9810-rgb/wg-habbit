"use client";

import { useEffect, useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { Compass, Dumbbell, Footprints, Shield, Trash2, Waves, Wind, Zap } from "lucide-react";

import { createClient } from "@/lib/supabase/client";
import { formatPoints } from "@/lib/utils";

type Reaction = { emoji: string; user_id: string };

type CrewEntry = {
  id: string;
  activity_type: string;
  points: number;
  distance_km: number | null;
  duration_min: number | null;
  reps: number | null;
  created_at: string;
  user_id: string;
  users: { name: string } | null;
  reactions: Reaction[];
};

const EMOJIS = ["🔥", "💪", "⚡", "👊"] as const;

type CrewLogFeedProps = {
  currentUserId?: string;
};

const ACTIVITY_ICONS: Record<string, React.ElementType> = {
  Running: Footprints, Walking: Waves, Gym: Dumbbell,
  "Muay Thai": Shield, Football: Footprints, Futsal: Footprints, Badminton: Footprints, Plank: Dumbbell, Swimming: Waves, Golf: Compass, "Male Kegel": Dumbbell, Stretch: Wind, "3L Water": Waves,
  "Push-ups": Zap, "Pull ups": Zap, "Sit Ups": Zap,
  "Abs Workout": Zap, "Pull-ups": Zap,
};

function getSummary(entry: CrewEntry) {
  if (entry.distance_km !== null) return `${entry.distance_km} km`;
  if (entry.duration_min !== null) return `${entry.duration_min} min`;
  return `${entry.reps ?? 0} reps`;
}

export function CrewLogFeed({ currentUserId }: CrewLogFeedProps) {
  const [entries, setEntries] = useState<CrewEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<string | null>(null);

  async function fetchToday() {
    const res = await fetch("/api/crew-log", { cache: "no-store" });
    const data = await res.json();
    setEntries(data.activities ?? []);
    setLoading(false);
  }

  async function handleReact(activityId: string, emoji: string) {
    await fetch("/api/reactions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ activity_id: activityId, emoji }),
    });
    await fetchToday();
  }

  async function handleDelete(id: string) {
    setDeleting(id);
    const res = await fetch(`/api/activities/${id}`, { method: "DELETE" });
    if (res.ok) {
      await fetchToday();
    } else {
      const err = await res.json();
      alert(`Could not delete: ${err.error ?? "Unknown error"}`);
    }
    setDeleting(null);
  }

  useEffect(() => {
    fetchToday();

    const supabase = createClient();
    const channel = supabase
      .channel("crew-log-realtime")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "activities" }, () => {
        fetchToday();
      })
      .subscribe();

    return () => { void supabase.removeChannel(channel); };
  }, []);

  return (
    <div className="rounded-[12px] p-5 flex flex-col gap-4" style={{ background: "#111111", border: "1px solid rgba(244,162,97,0.2)" }}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="label-caps" style={{ color: "rgba(244,162,97,0.6)" }}>Live — Resets Daily</p>
          <h2 className="mt-1 text-xl font-black uppercase tracking-[0.06em]" style={{ color: "#F1FAEE" }}>
            Today&apos;s Crew Log
          </h2>
        </div>
        <div className="flex items-center gap-2 rounded-[4px] px-3 py-1.5 text-xs font-bold"
          style={{ background: "rgba(34,197,94,0.1)", color: "#22c55e", border: "1px solid rgba(34,197,94,0.2)" }}>
          <span className="live-dot" />
          Live
        </div>
      </div>

      <div className="h-px" style={{ background: "rgba(241,250,238,0.07)" }} />

      {/* Entries */}
      <div className="flex flex-col gap-2 overflow-y-auto" style={{ maxHeight: 420 }}>
        {loading ? (
          <>
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 animate-pulse rounded-[8px]" style={{ background: "rgba(241,250,238,0.04)" }} />
            ))}
          </>
        ) : entries.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-3xl">⚓</p>
            <p className="mt-3 text-sm" style={{ color: "rgba(241,250,238,0.35)" }}>
              No crew activity logged today.
            </p>
            <p className="mt-1 text-xs" style={{ color: "rgba(241,250,238,0.2)" }}>
              Be the first to set sail.
            </p>
          </div>
        ) : (
          entries.map((entry) => {
            const Icon = ACTIVITY_ICONS[entry.activity_type] ?? Dumbbell;
            const isMe = entry.user_id === currentUserId;
            const name = entry.users?.name ?? "Crew member";

            return (
              <div
                key={entry.id}
                className="rounded-[8px] p-3 transition-all"
                style={{
                  background: isMe ? "rgba(230,57,70,0.07)" : "rgba(241,250,238,0.03)",
                  border: isMe ? "1px solid rgba(230,57,70,0.2)" : "1px solid rgba(241,250,238,0.06)",
                }}
              >
              <div className="flex items-center gap-3">
                {/* Activity icon */}
                <div
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[6px]"
                  style={{ background: isMe ? "rgba(230,57,70,0.15)" : "rgba(241,250,238,0.06)" }}
                >
                  <Icon className="h-4 w-4" style={{ color: isMe ? "#E63946" : "rgba(241,250,238,0.5)" }} />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-bold truncate" style={{ color: "#F1FAEE" }}>{name}</p>
                    {isMe && (
                      <span className="shrink-0 rounded-[3px] px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wider"
                        style={{ background: "rgba(230,57,70,0.2)", color: "#E63946" }}>
                        You
                      </span>
                    )}
                  </div>
                  <p className="text-xs" style={{ color: "rgba(241,250,238,0.4)" }}>
                    {entry.activity_type} · {getSummary(entry)}
                  </p>
                </div>

                {/* Points + time */}
                <div className="text-right shrink-0">
                  <p className="text-sm font-black" style={{ color: "#F4A261" }}>
                    +{formatPoints(entry.points)}
                  </p>
                  <p className="text-[10px]" style={{ color: "rgba(241,250,238,0.25)" }}>
                    {formatDistanceToNow(new Date(entry.created_at), { addSuffix: true })}
                  </p>
                </div>

                {/* Delete button — only for own entries */}
                {isMe && (
                  <button
                    onClick={() => handleDelete(entry.id)}
                    disabled={deleting === entry.id}
                    title="Delete this activity"
                    style={{
                      width: 32, height: 32, borderRadius: 6, border: "1px solid rgba(230,57,70,0.25)",
                      background: "rgba(230,57,70,0.08)", color: "#E63946", cursor: "pointer",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      opacity: deleting === entry.id ? 0.4 : 1,
                      transition: "all 0.2s", flexShrink: 0,
                    }}
                  >
                    <Trash2 size={13} />
                  </button>
                )}
              </div>

              {/* Reactions */}
              <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                {EMOJIS.map(emoji => {
                  const reacted = entry.reactions?.filter(r => r.emoji === emoji) ?? [];
                  const count   = reacted.length;
                  const iMine   = reacted.some(r => r.user_id === currentUserId);
                  return (
                    <button
                      key={emoji}
                      onClick={() => handleReact(entry.id, emoji)}
                      style={{
                        display: "flex", alignItems: "center", gap: 3,
                        padding: "2px 7px", borderRadius: 20, cursor: "pointer",
                        fontSize: 13, fontWeight: 700, transition: "all 0.15s",
                        background: iMine ? "rgba(244,162,97,0.15)" : "rgba(241,250,238,0.04)",
                        border: iMine ? "1px solid rgba(244,162,97,0.4)" : "1px solid rgba(241,250,238,0.08)",
                        color: iMine ? "#F4A261" : "rgba(241,250,238,0.5)",
                      }}
                    >
                      <span>{emoji}</span>
                      {count > 0 && <span style={{ fontSize: 10 }}>{count}</span>}
                    </button>
                  );
                })}
              </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer count */}
      {entries.length > 0 && (
        <div className="rounded-[4px] px-4 py-2.5 text-center text-xs font-semibold"
          style={{ background: "rgba(244,162,97,0.07)", color: "rgba(244,162,97,0.6)", border: "1px solid rgba(244,162,97,0.1)" }}>
          {entries.length} {entries.length === 1 ? "entry" : "entries"} from the crew today
        </div>
      )}
    </div>
  );
}
