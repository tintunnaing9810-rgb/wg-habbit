import { Gem, Sailboat } from "lucide-react";

import { getJourneyColor, getJourneyLabel, getJourneyTier } from "@/lib/journey";
import { formatPoints } from "@/lib/utils";

type DashboardStatsProps = {
  totalPoints: number;
  currentTitle: string;
  currentArc: string;
  nextMilestone: string;
  nextMilestonePoints: number;
  progressPercent: number;
};

export function DashboardStats(props: DashboardStatsProps) {
  const { totalPoints, currentTitle, currentArc, nextMilestone, nextMilestonePoints, progressPercent } = props;

  const journeyColor = getJourneyColor(totalPoints);
  const journeyLabel = getJourneyLabel(totalPoints);
  const journeyTier  = getJourneyTier(totalPoints);

  return (
    <section
      data-tier={journeyTier}
      className="journey-card overflow-hidden rounded-[1.25rem] p-6"
      style={{ "--journey-color": journeyColor, "--journey-color-dim": `${journeyColor}30` } as React.CSSProperties}
    >
      <div className="grid gap-6 sm:grid-cols-[1fr_auto]">

        {/* Left — identity */}
        <div className="grid gap-5">

          {/* Journey tier badge */}
          <div className="flex items-center gap-2">
            <span
              className="inline-flex items-center rounded-[4px] px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.2em]"
              style={{ background: `${journeyColor}20`, color: journeyColor, border: `1px solid ${journeyColor}40` }}
            >
              {journeyLabel}
            </span>
          </div>

          {/* Bounty */}
          <div className="flex items-center gap-4">
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[8px]"
              style={{ background: `${journeyColor}18` }}
            >
              <Gem className="h-6 w-6" style={{ color: journeyColor }} />
            </div>
            <div>
              <p className="label-caps">Total Bounty</p>
              <p className="hud-number mt-0.5 text-4xl font-black leading-none" style={{ color: journeyColor }}>
                {formatPoints(totalPoints)}
                <span className="ml-1.5 text-base font-semibold" style={{ color: `${journeyColor}80` }}>pts</span>
              </p>
            </div>
          </div>

          {/* Divider */}
          <div className="h-px" style={{ background: `${journeyColor}25` }} />

          {/* Chapter + Arc + Rank */}
          <div className="grid grid-cols-2 gap-x-6 gap-y-4">
            <div>
              <p className="label-caps">Arc</p>
              <p className="mt-1 text-sm font-semibold text-softwhite/80">{currentArc}</p>
            </div>
            <div>
              <p className="label-caps">Current Rank</p>
              <p className="mt-1 text-sm font-bold text-softwhite">{currentTitle}</p>
            </div>
          </div>
        </div>

        {/* Right — sailing progress */}
        <div className="flex flex-col gap-4 sm:w-44">

          {/* Vertical ocean bar */}
          <div
            className="relative flex-1 overflow-hidden rounded-[8px]"
            style={{ minHeight: 120, background: "rgba(241,250,238,0.05)", border: `1px solid ${journeyColor}25` }}
          >
            {/* Fill from bottom */}
            <div
              className="absolute bottom-0 left-0 right-0 transition-all duration-700"
              style={{
                height: `${Math.max(progressPercent, 4)}%`,
                background: `linear-gradient(0deg, ${journeyColor}, ${journeyColor}80)`,
                boxShadow: `0 0 16px ${journeyColor}60`,
              }}
            />
            {/* Waterline */}
            <div
              className="absolute left-0 right-0 transition-all duration-700"
              style={{
                bottom: `${Math.max(progressPercent, 4)}%`,
                height: 2,
                background: journeyColor,
                boxShadow: `0 0 8px ${journeyColor}`,
              }}
            />
            {/* Ship */}
            <div
              className="absolute left-1/2 -translate-x-1/2 transition-all duration-700"
              style={{ bottom: `calc(${Math.max(progressPercent, 4)}% + 6px)` }}
            >
              <Sailboat className="h-5 w-5 animate-wave-float drop-shadow-[0_2px_6px_rgba(244,162,97,0.6)]" style={{ color: "#F4A261" }} />
            </div>
            <p className="absolute inset-x-0 top-2 text-center text-[9px] font-bold uppercase tracking-widest text-softwhite/20">Next</p>
            <p className="absolute inset-x-0 bottom-2 text-center text-[9px] font-bold uppercase tracking-widest text-softwhite/20">Now</p>
          </div>

          {/* 4px progress bar */}
          <div>
            <div className="progress-track" style={{ ["--journey-color" as string]: journeyColor }}>
              <div
                className="progress-fill"
                style={{
                  width: `${progressPercent}%`,
                  background: `linear-gradient(90deg, ${journeyColor}, ${journeyColor}cc)`,
                  boxShadow: `0 0 8px ${journeyColor}`,
                }}
              />
            </div>
            <p className="mt-2 text-[11px] truncate">
              <span className="font-bold uppercase tracking-wider" style={{ color: "rgba(241,250,238,0.3)" }}>To </span>
              <span className="font-semibold" style={{ color: "rgba(241,250,238,0.65)" }}>{nextMilestone}</span>
              <span style={{ color: "rgba(241,250,238,0.3)" }}> — {formatPoints(nextMilestonePoints)} pts</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
