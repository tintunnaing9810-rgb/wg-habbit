import { ShipWheel } from "lucide-react";

import { SignOutButton } from "@/components/sign-out-button";
import { SidebarNav } from "@/components/sidebar-nav";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMilestone, getCurrentMonth } from "@/lib/progression";
import { formatPoints } from "@/lib/utils";

export async function AppSidebar() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profileRaw } = user
    ? await supabase.from("users").select("name, total_points").eq("id", user.id).single()
    : { data: null };
  const profile = profileRaw as { name: string; total_points: number } | null;

  const milestone = profile ? getCurrentMilestone(profile.total_points) : null;
  const month = profile ? getCurrentMonth(profile.total_points) : null;

  return (
    <aside className="flex h-fit flex-col rounded-[1.75rem] bg-[#080f1a] shadow-dark-lg" style={{ border: "1px solid rgba(216,164,55,0.15)" }}>
      {/* Logo header */}
      <div className="px-5 pb-5 pt-5">
        <div className="flex items-center gap-3">
          <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gold/15">
            <ShipWheel className="h-6 w-6 animate-spin-slow text-gold" />
          </div>
          <div>
            <p className="font-[var(--font-display)] text-[1.35rem] leading-none text-white">
              Worst Generation
            </p>
            <p className="mt-0.5 text-[11px] text-white/40 tracking-wide uppercase">Grand Line Logbook</p>
          </div>
        </div>
      </div>

      {/* Gold top border decoration */}
      <div className="mx-5 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />

      {/* Player WANTED mini-panel */}
      {profile && milestone && month ? (
        <div className="mx-5 mt-4">
          <div className="wanted-card relative overflow-hidden rounded-xl px-4 py-4">
            {/* Decorative corner stars */}
            <span className="absolute left-2 top-2 text-[10px] text-[#5a3515]/50">✦</span>
            <span className="absolute right-2 top-2 text-[10px] text-[#5a3515]/50">✦</span>

            <div className="text-center">
              <p className="text-[9px] font-black uppercase tracking-[0.3em] text-[#5a3515]/70">
                — Wanted —
              </p>
              <div className="mx-auto mt-2 flex h-14 w-14 items-center justify-center rounded-full border-2 border-[#5a3515]/30 bg-[#c4883d]/15">
                <p className="text-2xl font-black text-[#5a3515]/50">
                  {profile.name?.charAt(0)?.toUpperCase() ?? "?"}
                </p>
              </div>
              <p className="mt-2 text-base font-black leading-tight text-[#1a0800]">{profile.name}</p>
              <p className="text-[11px] text-[#5a3515]/70">{milestone.title}</p>
              <div className="mt-2 border-t border-[#5a3515]/20 pt-2">
                <p className="text-[9px] uppercase tracking-[0.15em] text-[#5a3515]/60">Bounty</p>
                <p className="text-xl font-black text-[#8b0000]">{formatPoints(profile.total_points)}</p>
                <p className="text-[9px] text-[#5a3515]/50">Berries</p>
              </div>
            </div>

            <span className="absolute bottom-2 left-2 text-[10px] text-[#5a3515]/50">✦</span>
            <span className="absolute bottom-2 right-2 text-[10px] text-[#5a3515]/50">✦</span>
          </div>
          <p className="mt-2 text-center text-[10px] uppercase tracking-widest text-gold/50">{month.title}</p>
        </div>
      ) : null}

      <div className="mx-5 mt-4 h-px bg-gradient-to-r from-transparent via-white/8 to-transparent" />

      {/* Navigation */}
      <div className="px-3 py-4">
        <SidebarNav />
      </div>

      <div className="mx-5 h-px bg-gradient-to-r from-transparent via-white/8 to-transparent" />

      {/* Sign out */}
      <div className="p-4">
        <SignOutButton />
      </div>
    </aside>
  );
}
