import { getCurrentMilestone, type UserProfile } from "@/lib/progression";
import { getStreakColor, getStreakEmoji } from "@/lib/streak";
import { formatPoints } from "@/lib/utils";

type LeaderboardTableProps = { users: UserProfile[]; startRank?: number; pointsKey?: string };

export function LeaderboardTable({ users, startRank = 1, pointsKey }: LeaderboardTableProps) {
  if (users.length === 0) {
    return (
      <div className="rounded-[12px] p-10 text-center" style={{ background: "#111111", border: "1px solid rgba(241,250,238,0.07)" }}>
        <p className="text-4xl">⚓</p>
        <p className="mt-4 text-sm" style={{ color: "rgba(241,250,238,0.35)" }}>No pirates on the board yet.</p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-[12px]" style={{ background: "#111111", border: "1px solid rgba(241,250,238,0.08)" }}>
      {users.map((user, index) => {
        const globalRank = startRank + index;
        const level      = getCurrentMilestone(user.total_points);
        const streak     = (user as Record<string, unknown>).streak_count as number ?? 0;
        const status     = (user as Record<string, unknown>).streak_status as string ?? "active";
        const streakColor = getStreakColor(status);
        const streakEmoji = getStreakEmoji(status);
        const isLast      = index === users.length - 1;

        return (
          <div
            key={user.id}
            className="flex items-center gap-3 px-4 py-3.5"
            style={{
              borderBottom: isLast ? "none" : "1px solid rgba(241,250,238,0.05)",
              borderLeft: "3px solid transparent",
            }}
          >
            {/* Rank */}
            <div className="w-8 shrink-0 text-center">
              <span className="text-sm font-black" style={{ color: "rgba(241,250,238,0.3)" }}>
                {globalRank}
              </span>
            </div>

            {/* Name + level */}
            <div className="min-w-0 flex-1">
              <p className="font-black leading-tight truncate text-sm" style={{ color: "#F1FAEE" }}>
                {user.name}
              </p>
              <p className="text-[11px] mt-0.5 truncate" style={{ color: "rgba(241,250,238,0.35)" }}>
                {level.title}
              </p>
            </div>

            {/* Streak */}
            <div className="flex flex-col items-center shrink-0 w-10">
              <span className="text-base leading-none">{streakEmoji}</span>
              <span className="text-[11px] font-black mt-0.5" style={{ color: streakColor }}>
                {streak}d
              </span>
              {streak >= 30 && (
                <span className="text-[8px] font-black rounded-[2px] px-1 mt-0.5" style={{ background: "rgba(208,0,0,0.2)", color: "#D00000" }}>ELITE</span>
              )}
            </div>

            {/* Points */}
            <div className="text-right shrink-0">
              <p className="font-black leading-none text-sm" style={{ color: "rgba(241,250,238,0.7)" }}>
                {formatPoints(pointsKey ? ((user as Record<string, unknown>)[pointsKey] as number ?? 0) : user.total_points)}
              </p>
              <p className="text-[10px] mt-0.5" style={{ color: "rgba(241,250,238,0.25)" }}>berries</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
