"use client";

import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { Compass, LoaderCircle, Ruler, Timer, Zap } from "lucide-react";

import { activityOptions } from "@/lib/constants";
import { months } from "@/lib/progression";
import { ChapterUnlockPopup } from "@/components/chapter-unlock-popup";
import type { StoryMonth } from "@/lib/progression";

type SubmissionState = {
  error: string | null;
  success: string | null;
};

const UNLOCK_THRESHOLDS = [1000, 2000];

type LogActivityFormProps = {
  totalPoints?: number;
};

export function LogActivityForm({ totalPoints = 0 }: LogActivityFormProps) {
  const router = useRouter();
  const [activityType, setActivityType] = useState(activityOptions[0].value as string);
  const [distanceKm, setDistanceKm] = useState("");
  const [durationMin, setDurationMin] = useState("");
  const [reps, setReps] = useState("");
  const [pending, setPending] = useState(false);
  const [state, setState] = useState<SubmissionState>({ error: null, success: null });
  const [unlockedMonth, setUnlockedMonth] = useState<StoryMonth | null>(null);
  const [flash, setFlash] = useState(false);

  const selected = activityOptions.find((option) => option.value === activityType) ?? activityOptions[0];

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setState({ error: null, success: null });

    const payload = {
      activityType,
      distanceKm: distanceKm ? Number(distanceKm) : null,
      durationMin: durationMin ? Number(durationMin) : null,
      reps: reps ? Number(reps) : null,
    };

    const response = await fetch("/api/activities", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const result = await response.json();

    if (!response.ok) {
      const message =
        result?.error?.fieldErrors?.distanceKm?.[0] ||
        result?.error?.fieldErrors?.durationMin?.[0] ||
        result?.error?.fieldErrors?.reps?.[0] ||
        result?.error ||
        "Unable to save activity.";
      setState({ error: message, success: null });
      setPending(false);
      return;
    }

    setDistanceKm("");
    setDurationMin("");
    setReps("");

    const earned = result.activity?.awarded_points ?? 0;
    const newTotal = totalPoints + earned;

    const crossedThreshold = UNLOCK_THRESHOLDS.find(
      (threshold) => totalPoints < threshold && newTotal >= threshold,
    );

    if (crossedThreshold !== undefined) {
      const nextMonth = months.find((m) => m.min === crossedThreshold) ?? null;
      setUnlockedMonth(nextMonth);
    }

    const streakMsg = result.streak?.message ?? null;
    const bonusMsg  = result.streak?.bonusPoints > 0 ? ` +${result.streak.bonusPoints} streak bonus!` : "";
    setState({
      error: null,
      success: `Logged! You earned ${earned} bounty points.${bonusMsg}${streakMsg ? `\n${streakMsg}` : ""}`,
    });
    setPending(false);
    setFlash(true);
    setTimeout(() => setFlash(false), 700);
    router.refresh();
  }

  return (
    <>
      {unlockedMonth ? (
        <ChapterUnlockPopup month={unlockedMonth} onDismiss={() => setUnlockedMonth(null)} />
      ) : null}

      {/* Logbook form with red flash on complete */}
      <div className={`parchment-card relative overflow-hidden rounded-[1.75rem] p-7 ${flash ? "animate-red-pulse" : ""}`}>
        {/* Corner decorations */}
        <span className="absolute left-4 top-4 text-sm text-[#5a3515]/25">✦</span>
        <span className="absolute right-4 top-4 text-sm text-[#5a3515]/25">✦</span>
        <span className="absolute bottom-4 left-4 text-sm text-[#5a3515]/25">✦</span>
        <span className="absolute bottom-4 right-4 text-sm text-[#5a3515]/25">✦</span>

        {/* Header */}
        <div className="text-center">
          <p className="text-[9px] font-black uppercase tracking-[0.35em] text-[#5a3515]/50">
            &mdash; Ship&apos;s Record &mdash;
          </p>
          <h2 className="mt-1 font-[var(--font-display)] text-2xl text-[#1a0800]">Log Activity</h2>
          <div className="mx-auto mt-2 h-px w-24 bg-gradient-to-r from-transparent via-[#5a3515]/30 to-transparent" />
        </div>

        <form onSubmit={handleSubmit} className="mt-6 grid gap-5">
          {/* Activity selector */}
          <div className="grid gap-2">
            <label className="text-xs font-bold uppercase tracking-[0.15em] text-[#5a3515]/60">
              Activity Type
            </label>
            <div className="relative">
              <Compass className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#5a3515]/50" />
              <select
                value={activityType}
                onChange={(e) => setActivityType(e.target.value)}
                className="w-full appearance-none rounded-2xl border border-[#5a3515]/20 bg-[#f0e3c0]/60 px-11 py-3 text-sm text-[#1a0800] outline-none transition focus:border-[#5a3515]/50 focus:bg-[#f0e3c0]"
              >
                {activityOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Distance */}
          {selected.unit === "distance" && (
            <div className="grid gap-2">
              <label className="text-xs font-bold uppercase tracking-[0.15em] text-[#5a3515]/60">
                Distance (km)
              </label>
              <div className="relative">
                <Ruler className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#5a3515]/50" />
                <input
                  value={distanceKm}
                  onChange={(e) => setDistanceKm(e.target.value)}
                  type="number"
                  min="0.1"
                  step="0.1"
                  required
                  placeholder="5.0"
                  className="w-full rounded-2xl border border-[#5a3515]/20 bg-[#f0e3c0]/60 px-11 py-3 text-sm text-[#1a0800] outline-none transition placeholder:text-[#5a3515]/30 focus:border-[#5a3515]/50 focus:bg-[#f0e3c0]"
                />
              </div>
            </div>
          )}

          {/* Duration */}
          {selected.unit === "duration" && (
            <div className="grid gap-2">
              <label className="text-xs font-bold uppercase tracking-[0.15em] text-[#5a3515]/60">
                Duration (minutes)
              </label>
              <div className="relative">
                <Timer className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#5a3515]/50" />
                <input
                  value={durationMin}
                  onChange={(e) => setDurationMin(e.target.value)}
                  type="number"
                  min="1"
                  step="1"
                  required
                  placeholder="45"
                  className="w-full rounded-2xl border border-[#5a3515]/20 bg-[#f0e3c0]/60 px-11 py-3 text-sm text-[#1a0800] outline-none transition placeholder:text-[#5a3515]/30 focus:border-[#5a3515]/50 focus:bg-[#f0e3c0]"
                />
              </div>
            </div>
          )}

          {/* None-metric activities */}
          {selected.unit === "none" && activityType === "Stretch" && (
            <div className="rounded-2xl border border-[#5a3515]/20 bg-[#d8a437]/10 px-4 py-3 text-center">
              <p className="text-xs font-bold text-[#5a3515]/70">No data needed — just log it!</p>
              <p className="text-[10px] text-[#5a3515]/50 mt-0.5">Only available after logging another activity today. Earns +5 pts.</p>
            </div>
          )}
          {selected.unit === "none" && activityType === "3L Water" && (
            <div className="rounded-2xl border border-[#5a3515]/20 bg-[#d8a437]/10 px-4 py-3 text-center">
              <p className="text-xs font-bold text-[#5a3515]/70">💧 Drank 3L+ of water today?</p>
              <p className="text-[10px] text-[#5a3515]/50 mt-0.5">Once per day only. Earns +5 pts.</p>
            </div>
          )}

          {/* Reps */}
          {selected.unit === "reps" && (
            <div className="grid gap-2">
              <label className="text-xs font-bold uppercase tracking-[0.15em] text-[#5a3515]/60">
                Reps
              </label>
              <div className="relative">
                <Zap className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#5a3515]/50" />
                <input
                  value={reps}
                  onChange={(e) => setReps(e.target.value)}
                  type="number"
                  min="1"
                  step="1"
                  required
                  placeholder="50"
                  className="w-full rounded-2xl border border-[#5a3515]/20 bg-[#f0e3c0]/60 px-11 py-3 text-sm text-[#1a0800] outline-none transition placeholder:text-[#5a3515]/30 focus:border-[#5a3515]/50 focus:bg-[#f0e3c0]"
                />
              </div>
            </div>
          )}

          {/* Messages */}
          {state.error && (
            <p className="rounded-2xl border border-red-800/30 bg-red-900/20 px-4 py-3 text-xs text-red-400">
              {state.error}
            </p>
          )}
          {state.success && (
            <p className="rounded-2xl border border-[#5a3515]/20 bg-[#d8a437]/15 px-4 py-3 text-xs font-semibold text-[#5a3515]">
              ⚓ {state.success}
            </p>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={pending}
            className="btn-primary w-full"
          >
            {pending && <LoaderCircle className="h-4 w-4 animate-spin" />}
            {pending ? "Logging..." : "⚡ Record Activity"}
          </button>
        </form>
      </div>
    </>
  );
}
