"use client";

import { useRef, useState } from "react";
import { Camera, Loader2 } from "lucide-react";

import { createClient } from "@/lib/supabase/client";
import { getJourneyColor, getJourneyLabel } from "@/lib/journey";
import { getCurrentMilestone } from "@/lib/progression";
import { formatPoints } from "@/lib/utils";

type WantedPosterProps = {
  userId: string;
  name: string;
  totalPoints: number;
  avatarUrl: string | null;
  compact?: boolean;
};

export function WantedPoster({ userId, name, totalPoints, avatarUrl, compact = false }: WantedPosterProps) {
  const [photo, setPhoto]         = useState<string | null>(avatarUrl);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const journeyColor = getJourneyColor(totalPoints);
  const journeyLabel = getJourneyLabel(totalPoints);
  const milestone    = getCurrentMilestone(totalPoints);

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const supabase = createClient();
      const ext  = file.name.split(".").pop() ?? "jpg";
      const path = `${userId}/avatar.${ext}`;
      await supabase.storage.from("avatars").upload(path, file, { upsert: true });
      const { data } = supabase.storage.from("avatars").getPublicUrl(path);
      setPhoto(`${data.publicUrl}?t=${Date.now()}`);
      await supabase.from("users").update({ avatar_url: data.publicUrl }).eq("id", userId);
    } finally {
      setUploading(false);
    }
  }

  const s = compact
    ? { maxW: 180, border: 4, pad: "8px 8px 8px",   wanted: "1.4rem", spacing: "0.08em", sub: "0.45rem", name: "0.75rem", bounty: "1.1rem", label: "7px", photoSize: "64px" }
    : { maxW: 210, border: 5, pad: "12px 10px 10px", wanted: "1.8rem", spacing: "0.1em",  sub: "0.55rem", name: "0.85rem", bounty: "1.3rem", label: "8px", photoSize: "100%" };

  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div
        style={{
          width: "100%",
          maxWidth: s.maxW,
          background: "linear-gradient(160deg, #f5e6c8 0%, #ead5a0 40%, #f0ddb0 70%, #e8cf98 100%)",
          border: `${s.border}px solid #2c1810`,
          boxShadow: "0 0 0 1px #5a3515, 0 12px 32px rgba(0,0,0,0.7), inset 0 0 60px rgba(44,24,16,0.1)",
          padding: s.pad,
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Aged lines overlay */}
        <div style={{ position: "absolute", inset: 0, pointerEvents: "none", opacity: 0.05, backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(44,24,16,0.4) 2px, rgba(44,24,16,0.4) 3px)" }} />

        {/* WANTED */}
        <div style={{ textAlign: "center", borderTop: "2px solid #2c1810", borderBottom: "2px solid #2c1810", padding: "3px 0", marginBottom: 6 }}>
          <p style={{ fontFamily: "Georgia, serif", fontSize: s.wanted, fontWeight: 900, color: "#1a0a04", letterSpacing: s.spacing, lineHeight: 1, textShadow: "1px 1px 0 rgba(44,24,16,0.2)" }}>
            WANTED
          </p>
        </div>

        {/* Dead or Alive */}
        <p style={{ textAlign: "center", fontFamily: "Georgia, serif", fontSize: s.sub, fontWeight: 700, color: "#2c1810", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: compact ? 8 : 10 }}>
          ── Dead or Alive ──
        </p>

        {/* Photo */}
        <div
          style={{ position: "relative", margin: compact ? "0 auto 8px" : "0 auto 10px", cursor: "pointer", overflow: "hidden", border: "3px solid #2c1810", boxShadow: "inset 0 0 12px rgba(44,24,16,0.3)", width: s.photoSize, aspectRatio: "1" }}
          onClick={() => !uploading && inputRef.current?.click()}
        >
          {photo ? (
            <img src={photo} alt={name} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
          ) : (
            <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg, #d4b896 0%, #c9a87c 100%)" }}>
              <span style={{ fontFamily: "Georgia, serif", fontSize: compact ? "2rem" : "3.5rem", fontWeight: 900, color: "#2c1810", opacity: 0.35 }}>
                {name.charAt(0).toUpperCase()}
              </span>
            </div>
          )}

          {/* Hover overlay */}
          <div className="group-hover:opacity-100" style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "rgba(44,24,16,0.6)", opacity: 0, transition: "opacity 0.2s" }}
            onMouseEnter={e => (e.currentTarget.style.opacity = "1")}
            onMouseLeave={e => (e.currentTarget.style.opacity = "0")}
          >
            {uploading ? <Loader2 size={compact ? 20 : 28} style={{ color: "#f5e6c8", animation: "spin 1s linear infinite" }} />
              : <><Camera size={compact ? 20 : 28} style={{ color: "#f5e6c8" }} /><p style={{ color: "#f5e6c8", fontSize: 9, fontWeight: 700, marginTop: 4, textTransform: "uppercase", letterSpacing: "0.1em" }}>Upload</p></>}
          </div>

          <input ref={inputRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handleFileChange} />
        </div>

        {/* Name */}
        <div style={{ textAlign: "center", borderTop: "2px solid #2c1810", borderBottom: "2px solid #2c1810", padding: "4px 2px", marginBottom: compact ? 6 : 8 }}>
          <p style={{ fontFamily: "Georgia, serif", fontSize: s.name, fontWeight: 900, color: "#1a0a04", textTransform: "uppercase", letterSpacing: "0.06em", lineHeight: 1.2, wordBreak: "break-word" }}>
            {name}
          </p>
        </div>

        {/* Bounty + Tier on one line */}
        <div style={{ borderTop: "2px solid #2c1810", paddingTop: compact ? 5 : 6, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 6 }}>
          <span style={{ fontFamily: "Georgia, serif", fontSize: s.label, fontWeight: 900, textTransform: "uppercase", letterSpacing: "0.05em", background: `${journeyColor}20`, color: journeyColor, border: `1px solid ${journeyColor}50`, padding: "2px 6px", flexShrink: 0 }}>
            {journeyLabel}
          </span>
          <p style={{ fontFamily: "Georgia, serif", fontSize: s.bounty, fontWeight: 900, color: "#1a0a04", lineHeight: 1, textAlign: "right" }}>
            ฿ {formatPoints(totalPoints)} <span style={{ fontSize: s.label, fontWeight: 600, color: "#5a3515" }}>Berries</span>
          </p>
        </div>
      </div>
    </div>
  );
}
