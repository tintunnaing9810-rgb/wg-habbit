import { formatDistanceToNow } from "date-fns";
import { Dumbbell, Footprints, Shield, Waves, Zap } from "lucide-react";

import { getActivityMeta, type Activity } from "@/lib/progression";
import { formatPoints } from "@/lib/utils";

type RecentActivitiesProps = { activities: Activity[] };

const ICON_MAP: Record<string, React.ElementType> = {
  Running: Footprints, Walking: Waves, Gym: Dumbbell, "Muay Thai": Shield,
  Football: Footprints, Futsal: Footprints, Badminton: Footprints, Plank: Dumbbell, Swimming: Waves, Golf: Footprints, "Male Kegel": Dumbbell, Stretch: Waves, "3L Water": Waves, "Push-ups": Zap, "Pull ups": Zap, "Sit Ups": Zap,
  "Abs Workout": Zap, "Pull-ups": Zap,
};

export function RecentActivities({ activities }: RecentActivitiesProps) {
  if (activities.length === 0) {
    return (
      <div className="mt-6 flex flex-col items-center gap-3 py-6 text-center">
        <p className="text-3xl">⚓</p>
        <p className="text-sm" style={{ color: "rgba(241,250,238,0.35)" }}>No training logged yet.</p>
      </div>
    );
  }

  return (
    <div className="mt-5 grid gap-2">
      {activities.map((activity) => {
        const meta = getActivityMeta(activity.activity_type);
        const summary = activity.distance_km !== null ? `${activity.distance_km} km`
          : activity.duration_min !== null ? `${activity.duration_min} min`
          : `${activity.reps ?? 0} reps`;
        const Icon = ICON_MAP[activity.activity_type] ?? Dumbbell;

        return (
          <div
            key={activity.id}
            className="flex items-center gap-3 rounded-[8px] p-3 transition"
            style={{ background: "rgba(241,250,238,0.04)", border: "1px solid rgba(241,250,238,0.07)" }}
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[6px]" style={{ background: "rgba(230,57,70,0.15)" }}>
              <Icon className="h-4 w-4" style={{ color: "#E63946" }} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold" style={{ color: "#F1FAEE" }}>{meta?.label ?? activity.activity_type}</p>
              <p className="text-xs" style={{ color: "rgba(241,250,238,0.4)" }}>{summary}</p>
            </div>
            <div className="text-right shrink-0">
              <p className="text-sm font-bold" style={{ color: "#F4A261" }}>+{formatPoints(activity.points)}</p>
              <p className="text-[10px]" style={{ color: "rgba(241,250,238,0.25)" }}>
                {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true })}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
