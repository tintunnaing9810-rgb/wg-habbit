type PageHeaderProps = {
  eyebrow: string;
  title: string;
  description?: string;
};

export function PageHeader({ eyebrow, title, description }: PageHeaderProps) {
  return (
    <header className="game-card rounded-[1.25rem] p-6">
      <p className="label-caps">{eyebrow}</p>
      <h1 className="mt-3 text-3xl font-black uppercase tracking-tight text-softwhite md:text-4xl">
        {title}
      </h1>
      {description && <p className="mt-3 max-w-3xl text-sm leading-7 text-softwhite/50">{description}</p>}
    </header>
  );
}
