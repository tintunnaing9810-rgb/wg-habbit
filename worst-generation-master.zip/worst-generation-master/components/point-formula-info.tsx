const FORMULAS = [
  { icon: "🏃", activity: "Running",     calc: "per km",  rate: "× 5.5 pts" },
  { icon: "🚶", activity: "Walking",     calc: "per km",  rate: "× 3 pts" },
  { icon: "💪", activity: "Gym",         calc: "per min", rate: "× 0.8 pts" },
  { icon: "🥊", activity: "Muay Thai",   calc: "per min", rate: "× 0.8 pts" },
  { icon: "⚽", activity: "Futsal",      calc: "per min", rate: "× 0.8 pts" },
  { icon: "🏸", activity: "Badminton",   calc: "per min", rate: "× 0.8 pts" },
  { icon: "🧘", activity: "Plank",       calc: "per min", rate: "× 1 pt" },
  { icon: "🏊", activity: "Swimming",    calc: "per min", rate: "× 0.8 pts" },
  { icon: "🔁", activity: "Push-ups",    calc: "per rep", rate: "× 0.4 pts" },
  { icon: "🔁", activity: "Pull ups",    calc: "per rep", rate: "× 0.5 pts" },
  { icon: "🔁", activity: "Sit Ups",     calc: "per rep", rate: "× 0.2 pts" },
  { icon: "🔁", activity: "Abs Workout",  calc: "per rep",   rate: "× 0.4 pts" },
  { icon: "🔁", activity: "Male Kegel",   calc: "per rep",   rate: "× 0.2 pts" },
  { icon: "⛳", activity: "Golf",          calc: "per min",    rate: "× 0.3 pts" },
  { icon: "💧", activity: "3L Water",     calc: "flat bonus", rate: "+5 pts" },
  { icon: "🧘", activity: "Stretch",      calc: "flat bonus", rate: "+5 pts" },
];

export function PointFormulaInfo() {
  return (
    <section className="rounded-[12px] p-5" style={{ background: "#111111", border: "1px solid rgba(241,250,238,0.08)" }}>
      <p className="label-caps mb-1">How points are earned</p>
      <h2 className="text-base font-black uppercase tracking-[0.06em] mb-4" style={{ color: "#F1FAEE" }}>
        Bounty Formula
      </h2>

      <div className="space-y-1.5">
        {FORMULAS.map(f => (
          <div
            key={f.activity}
            className="flex items-center justify-between rounded-[6px] px-3 py-2"
            style={{ background: "rgba(241,250,238,0.03)", border: "1px solid rgba(241,250,238,0.06)" }}
          >
            <div className="flex items-center gap-2">
              <span className="text-sm">{f.icon}</span>
              <span className="text-xs font-semibold" style={{ color: "rgba(241,250,238,0.7)" }}>{f.activity}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px]" style={{ color: "rgba(241,250,238,0.3)" }}>{f.calc}</span>
              <span
                className="text-[10px] font-black rounded-[3px] px-1.5 py-0.5"
                style={{ background: "rgba(244,162,97,0.12)", color: "#F4A261", border: "1px solid rgba(244,162,97,0.2)" }}
              >
                {f.rate}
              </span>
            </div>
          </div>
        ))}
      </div>

      <p className="mt-3 text-[10px] text-center" style={{ color: "rgba(241,250,238,0.2)" }}>
        Points are rounded to the nearest whole number
      </p>
    </section>
  );
}
