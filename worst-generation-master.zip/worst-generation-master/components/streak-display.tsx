"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import { getStreakColor, getStreakEmoji, getDaysUntilExpiry } from "@/lib/streak";

type StreakDisplayProps = {
  streakCount: number;
  streakStatus: string;
  restDayUsed: boolean;
  frozenAt: string | null;
  totalPoints: number;
};

export function StreakDisplay({ streakCount, streakStatus, restDayUsed, frozenAt, totalPoints }: StreakDisplayProps) {
  const [showConfirm, setShowConfirm] = useState(false);
  const [recovering, setRecovering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const color    = getStreakColor(streakStatus);
  const emoji    = getStreakEmoji(streakStatus);
  const daysLeft = getDaysUntilExpiry(frozenAt);
  const isFrozen = streakStatus === "frozen";
  const canRecover = isFrozen && daysLeft !== null && daysLeft >= 0 && totalPoints >= 50;

  async function handleRecover() {
    setRecovering(true);
    setError(null);
    const res = await fetch("/api/streak/recover", { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      setShowConfirm(false);
      router.refresh();
    } else {
      setError(data.error ?? "Recovery failed");
    }
    setRecovering(false);
  }

  return (
    <>
      {/* Streak card */}
      <div
        className="rounded-[12px] p-5"
        style={{
          background: "#111111",
          border: `1px solid ${color}35`,
          boxShadow: `0 0 20px ${color}12`,
        }}
      >
        {/* Header row */}
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div
              className="flex h-12 w-12 items-center justify-center rounded-[8px] text-2xl"
              style={{ background: `${color}15` }}
            >
              {emoji}
            </div>
            <div>
              <p className="label-caps" style={{ color: `${color}80` }}>
                Daily Streak
              </p>
              <p className="text-3xl font-black leading-none" style={{ color }}>
                {streakCount}
                <span className="ml-1.5 text-base font-semibold" style={{ color: `${color}60` }}>
                  {streakCount === 1 ? "day" : "days"}
                </span>
              </p>
            </div>
          </div>

          {/* Status badge */}
          <div
            className="rounded-[4px] px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.2em]"
            style={{ background: `${color}15`, color, border: `1px solid ${color}35` }}
          >
            {isFrozen ? "Frozen" : streakStatus === "broken" ? "Broken" : "Active"}
          </div>
        </div>

        {/* Info row */}
        <div className="mt-4 flex items-center justify-between gap-4">
          {/* Rest day status */}
          <div
            className="flex items-center gap-2 rounded-[4px] px-3 py-2 text-xs font-semibold"
            style={{
              background: restDayUsed ? "rgba(241,250,238,0.04)" : "rgba(34,197,94,0.08)",
              border: `1px solid ${restDayUsed ? "rgba(241,250,238,0.08)" : "rgba(34,197,94,0.2)"}`,
              color: restDayUsed ? "rgba(241,250,238,0.35)" : "#22c55e",
            }}
          >
            🛌 Rest day: {restDayUsed ? "Used" : "Available"}
          </div>

          {/* Freeze expiry warning */}
          {isFrozen && daysLeft !== null && (
            <p className="text-xs font-semibold" style={{ color: "#E63946" }}>
              ⚠️ {daysLeft === 0 ? "Expires today!" : `${daysLeft}d to recover`}
            </p>
          )}
        </div>

        {/* Milestone progress hints */}
        {!isFrozen && (
          <div className="mt-4">
            <div className="flex items-center justify-between text-[10px]" style={{ color: "rgba(241,250,238,0.3)" }}>
              <span>🔥 3d milestone</span>
              <span>⚡ 7d (+10pts)</span>
              <span>🏆 14d boost</span>
              <span>☠️ 30d elite</span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full" style={{ background: "rgba(241,250,238,0.06)" }}>
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${Math.min((streakCount / 30) * 100, 100)}%`,
                  background: `linear-gradient(90deg, ${color}, ${color}cc)`,
                  boxShadow: `0 0 6px ${color}`,
                }}
              />
            </div>
          </div>
        )}

        {/* Recover button */}
        {isFrozen && (
          <div className="mt-4">
            {canRecover ? (
              <button
                onClick={() => setShowConfirm(true)}
                className="btn-primary w-full"
                style={{ background: "#5fa8d3" }}
              >
                🔥 Recover Streak — 50 pts
              </button>
            ) : (
              <div
                className="rounded-[4px] px-4 py-3 text-center text-xs"
                style={{ background: "rgba(230,57,70,0.08)", color: "#E63946", border: "1px solid rgba(230,57,70,0.2)" }}
              >
                {daysLeft === 0 || (daysLeft !== null && daysLeft < 0)
                  ? "💥 Recovery window expired — streak broken"
                  : totalPoints < 50
                  ? `Need 50 pts to recover (you have ${totalPoints})`
                  : "Streak cannot be recovered"}
              </div>
            )}
            {error && (
              <p className="mt-2 text-center text-xs" style={{ color: "#E63946" }}>{error}</p>
            )}
          </div>
        )}
      </div>

      {/* Confirmation popup */}
      {showConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(4px)" }}
          onClick={() => setShowConfirm(false)}
        >
          <div
            className="w-full max-w-sm rounded-[12px] p-6"
            style={{ background: "#111111", border: "1px solid rgba(95,168,211,0.35)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-xl font-black text-center" style={{ color: "#F1FAEE" }}>
              🔥 Recover Your Streak?
            </p>
            <p className="mt-3 text-sm text-center leading-6" style={{ color: "rgba(241,250,238,0.55)" }}>
              This will cost <strong style={{ color: "#F4A261" }}>50 bounty points</strong> and restore your{" "}
              <strong style={{ color: "#5fa8d3" }}>{streakCount}-day streak</strong>.
            </p>
            <p className="mt-1 text-xs text-center" style={{ color: "rgba(241,250,238,0.3)" }}>
              You have {totalPoints} pts → {totalPoints - 50} after recovery
            </p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button
                onClick={() => setShowConfirm(false)}
                className="btn-ghost"
              >
                Cancel
              </button>
              <button
                onClick={handleRecover}
                disabled={recovering}
                className="btn-primary"
                style={{ background: "#5fa8d3" }}
              >
                {recovering ? "Recovering…" : "Confirm"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
