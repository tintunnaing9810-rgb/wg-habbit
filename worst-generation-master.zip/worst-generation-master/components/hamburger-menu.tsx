"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Compass, History, Map, ScrollText, Trophy, X, LogOut } from "lucide-react";

import { createClient } from "@/lib/supabase/client";
import { WantedPoster } from "@/components/wanted-poster";

type HamburgerMenuProps = {
  userName: string;
  totalPoints: number;
  userId: string;
  avatarUrl: string | null;
};

const navItems = [
  { href: "/dashboard",   label: "Dashboard",    icon: Compass,     sub: "Grand Line HQ" },
  { href: "/log",         label: "Ship's Log",   icon: ScrollText,  sub: "Record activity" },
  { href: "/history",     label: "My Record",    icon: History,     sub: "Full history" },
  { href: "/leaderboard", label: "Bounty Board", icon: Trophy,      sub: "Crew standings" },
  { href: "/progress",    label: "Treasure Map", icon: Map,         sub: "Your journey" },
];

export function HamburgerMenu({ userName, totalPoints: initialPoints, userId, avatarUrl }: HamburgerMenuProps) {
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [points, setPoints] = useState(initialPoints);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => { setMounted(true); }, []);
  useEffect(() => { setOpen(false); }, [pathname]);

  // Keep points in sync with database changes
  useEffect(() => {
    const supabase = createClient();
    const channel = supabase
      .channel("user-points-sync")
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "users", filter: `id=eq.${userId}` },
        (payload) => {
          const newPoints = (payload.new as { total_points: number }).total_points;
          setPoints(newPoints);
        },
      )
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [userId]);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  async function handleSignOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  const panel = (
    <>
      {/* Backdrop — renders directly on body */}
      <div
        onClick={() => setOpen(false)}
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 9998,
          background: "rgba(0,0,0,0.7)",
          backdropFilter: "blur(4px)",
          opacity: open ? 1 : 0,
          pointerEvents: open ? "auto" : "none",
          transition: "opacity 0.3s ease",
        }}
      />

      {/* Slide panel */}
      <div
        style={{
          position: "fixed",
          top: 0,
          right: 0,
          bottom: 0,
          width: "300px",
          zIndex: 9999,
          background: "#080f1a",
          borderLeft: "1px solid rgba(216,164,55,0.2)",
          boxShadow: "-8px 0 40px rgba(0,0,0,0.7)",
          transform: open ? "translateX(0)" : "translateX(100%)",
          transition: "transform 0.3s ease",
          overflowY: "auto",
          overflowX: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 20px", flexShrink: 0 }}>
          <p style={{ fontSize: "10px", fontWeight: 700, letterSpacing: "0.25em", textTransform: "uppercase", color: "rgba(216,164,55,0.5)" }}>
            Menu
          </p>
          <button
            onClick={() => setOpen(false)}
            style={{ width: 36, height: 36, borderRadius: 12, border: "1px solid rgba(255,255,255,0.1)", background: "transparent", color: "rgba(255,255,255,0.5)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}
          >
            <X size={16} />
          </button>
        </div>

        {/* Wanted poster */}
        <div style={{ margin: "0 16px", flexShrink: 0 }}>
          <WantedPoster
            userId={userId}
            name={userName}
            totalPoints={points}
            avatarUrl={avatarUrl}
            compact
          />
        </div>

        {/* Divider */}
        <div style={{ height: 1, margin: "16px 16px 8px", background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)", flexShrink: 0 }} />

        {/* Nav links */}
        <nav style={{ padding: "0 12px", flexShrink: 0 }}>
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "12px 16px",
                  borderRadius: 16,
                  marginBottom: 4,
                  textDecoration: "none",
                  border: active ? "1px solid rgba(216,164,55,0.3)" : "1px solid transparent",
                  background: active ? "rgba(216,164,55,0.1)" : "transparent",
                  transition: "all 0.2s",
                }}
              >
                <div style={{
                  width: 36, height: 36, borderRadius: 12, flexShrink: 0,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  background: active ? "rgba(216,164,55,0.2)" : "rgba(255,255,255,0.06)",
                  color: active ? "#d8a437" : "rgba(255,255,255,0.5)",
                }}>
                  <Icon size={16} />
                </div>
                <div>
                  <p style={{ fontSize: 14, fontWeight: 600, color: active ? "#d8a437" : "rgba(255,255,255,0.85)", margin: 0, lineHeight: 1 }}>
                    {item.label}
                  </p>
                  <p style={{ fontSize: 11, color: active ? "rgba(216,164,55,0.6)" : "rgba(255,255,255,0.35)", margin: "4px 0 0" }}>
                    {item.sub}
                  </p>
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Divider */}
        <div style={{ height: 1, margin: "8px 16px", background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)", flexShrink: 0 }} />

        {/* Leave crew */}
        <div style={{ padding: 16, flexShrink: 0 }}>
          <button
            onClick={handleSignOut}
            style={{
              width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              padding: "12px 16px", borderRadius: 16, border: "1px solid rgba(255,255,255,0.08)",
              background: "transparent", color: "rgba(255,255,255,0.4)", fontSize: 14, fontWeight: 600,
              cursor: "pointer", transition: "all 0.2s",
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = "#e76f51"; (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(231,111,81,0.3)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = "rgba(255,255,255,0.4)"; (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.08)"; }}
          >
            <LogOut size={16} />
            Leave Crew
          </button>
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Hamburger button — stays in header */}
      <button
        onClick={() => setOpen(true)}
        style={{ width: 40, height: 40, borderRadius: 12, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 5 }}
        aria-label="Open menu"
      >
        <span style={{ width: 20, height: 2, borderRadius: 1, background: "rgba(255,255,255,0.8)", display: "block" }} />
        <span style={{ width: 14, height: 2, borderRadius: 1, background: "rgba(255,255,255,0.8)", display: "block" }} />
        <span style={{ width: 20, height: 2, borderRadius: 1, background: "rgba(255,255,255,0.8)", display: "block" }} />
      </button>

      {/* Portal — renders at body level, escapes header stacking context */}
      {mounted && createPortal(panel, document.body)}
    </>
  );
}
