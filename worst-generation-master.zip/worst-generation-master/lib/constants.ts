import { Compass, Dumbbell, Footprints, Shield, Waves, Wind } from "lucide-react";

export const activityOptions = [
  { value: "Running",      label: "Running",      unit: "distance" as const, icon: Footprints },
  { value: "Walking",      label: "Walking",      unit: "distance" as const, icon: Waves },
  { value: "Swimming",     label: "Swimming",     unit: "duration" as const, icon: Waves },
  { value: "Gym",          label: "Gym",          unit: "duration" as const, icon: Dumbbell },
  { value: "Muay Thai",    label: "Muay Thai",    unit: "duration" as const, icon: Shield },
  { value: "Futsal",       label: "Futsal",       unit: "duration" as const, icon: Compass },
  { value: "Badminton",    label: "Badminton",    unit: "duration" as const, icon: Compass },
  { value: "Plank",        label: "Plank",        unit: "duration" as const, icon: Dumbbell },
  { value: "Push-ups",     label: "Push-ups",     unit: "reps" as const,     icon: Dumbbell },
  { value: "Pull ups",     label: "Pull ups",     unit: "reps" as const,     icon: Dumbbell },
  { value: "Sit Ups",      label: "Sit Ups",      unit: "reps" as const,     icon: Dumbbell },
  { value: "Abs Workout",  label: "Abs Workout",  unit: "reps" as const,     icon: Dumbbell },
  { value: "Male Kegel",   label: "Male Kegel",   unit: "reps" as const,     icon: Dumbbell },
  { value: "Golf",         label: "Golf",         unit: "duration" as const, icon: Compass },
  { value: "3L Water",    label: "3L Water 💧 (+5 pts)", unit: "none" as const, icon: Waves },
  { value: "Stretch",     label: "Stretch 🧘 (+5 pts)",  unit: "none" as const, icon: Wind },
] as const;

export const protectedRoutes = ["/dashboard", "/leaderboard", "/log", "/progress"];
