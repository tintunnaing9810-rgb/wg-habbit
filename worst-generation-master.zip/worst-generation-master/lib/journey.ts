export type JourneyTier =
  | "east-blue-rookie"
  | "rookie-pirate"
  | "super-rookie"
  | "grand-line-survivor"
  | "new-world-pirate"
  | "rising-captain"
  | "notable-captain"
  | "fleet-captain"
  | "warlord"
  | "elite-pirate"
  | "yonko-subordinate"
  | "yonko-commander"
  | "first-commander"
  | "emperor"
  | "great-emperor"
  | "king-of-the-seas"
  | "pirate-king";

type TierDef = { min: number; max: number; label: string; color: string; tier: JourneyTier };

export const JOURNEY_TIERS: TierDef[] = [
  { tier: "east-blue-rookie",    min: 0,    max: 400,  label: "East Blue Rookie",        color: "#2A9D8F" },
  { tier: "rookie-pirate",       min: 400,  max: 800,  label: "Rookie Pirate",           color: "#52B788" },
  { tier: "super-rookie",        min: 800,  max: 1200, label: "Super Rookie",            color: "#90BE6D" },
  { tier: "grand-line-survivor", min: 1200, max: 1600, label: "Grand Line Survivor",     color: "#E9C46A" },
  { tier: "new-world-pirate",    min: 1600, max: 2000, label: "New World Pirate",        color: "#F4A261" },
  { tier: "rising-captain",      min: 2000, max: 2400, label: "Rising Captain",          color: "#E76F51" },
  { tier: "notable-captain",     min: 2400, max: 2800, label: "Notable Captain",         color: "#E63946" },
  { tier: "fleet-captain",       min: 2800, max: 3200, label: "Fleet Captain",           color: "#9D4EDD" },
  { tier: "warlord",             min: 3200, max: 3600, label: "Warlord",                 color: "#7B2FBE" },
  { tier: "elite-pirate",        min: 3600, max: 4000, label: "Elite Pirate",            color: "#4361EE" },
  { tier: "yonko-subordinate",   min: 4000, max: 4400, label: "Yonko Subordinate",       color: "#3A0CA3" },
  { tier: "yonko-commander",     min: 4400, max: 4800, label: "Yonko Commander",         color: "#D00000" },
  { tier: "first-commander",     min: 4800, max: 5200, label: "First Commander Level",   color: "#9D0208" },
  { tier: "emperor",             min: 5200, max: 5600, label: "Emperor (Yonko)",         color: "#FFD60A" },
  { tier: "great-emperor",       min: 5600, max: 5900, label: "Great Emperor",           color: "#FFBE0B" },
  { tier: "king-of-the-seas",    min: 5900, max: 6000, label: "King of the Seas",        color: "#A8DADC" },
  { tier: "pirate-king",         min: 6000, max: Infinity, label: "Pirate King",         color: "#FFD700" },
];

function getTierDef(points: number): TierDef {
  return JOURNEY_TIERS.find((t) => points >= t.min && points < t.max) ?? JOURNEY_TIERS[JOURNEY_TIERS.length - 1]!;
}

export function getJourneyTier(points: number): JourneyTier {
  return getTierDef(points).tier;
}

export function getJourneyColor(points: number): string {
  return getTierDef(points).color;
}

export function getJourneyLabel(points: number): string {
  return getTierDef(points).label;
}
