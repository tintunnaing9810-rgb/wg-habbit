import type { SupabaseClient } from "@supabase/supabase-js";

type StreakAction = "duplicate" | "first" | "active" | "rest_day" | "frozen" | "broken";

export type StreakResult = {
  streakCount: number;
  streakStatus: string;
  restDayUsed: boolean;
  message: string | null;
  bonusPoints: number;
  action: StreakAction;
};

function daysBetween(a: string, b: string): number {
  return Math.round(
    (new Date(b).getTime() - new Date(a).getTime()) / 86_400_000,
  );
}

function getISOWeek(dateStr: string): number {
  const d = new Date(dateStr);
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86_400_000) + 1) / 7);
}

const MESSAGES: Record<StreakAction, string> = {
  duplicate: "",
  first:     "🔥 The chain begins. Your journey starts now.",
  active:    "🔥 The chain continues.",
  rest_day:  "🛌 Even warriors must rest. Your fire remains.",
  frozen:    "❄️ Your journey is paused… don't let it end.",
  broken:    "💥 The chain is broken. Begin again.",
};

const MILESTONE_MESSAGES: Record<number, string> = {
  3:  "🔥 The ocean has tested you… and you're still standing. This is just the beginning.",
  7:  "⚡ You've survived your first week at sea. Most quit before this. You didn't.",
  14: "🌊 Two weeks of fire. The sea respects those who keep moving.",
  30: "☠️ 30 days. You are no longer a sailor. You are a legend.",
};

export async function updateStreak(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: SupabaseClient<any>,
  userId: string,
): Promise<StreakResult> {
  const today = new Date().toISOString().split("T")[0]!;

  const { data: user } = await supabase
    .from("users")
    .select("streak_count, last_activity_date, rest_day_used, streak_status, streak_frozen_at, total_points")
    .eq("id", userId)
    .single();

  if (!user) {
    return { streakCount: 0, streakStatus: "active", restDayUsed: false, message: null, bonusPoints: 0, action: "active" };
  }

  const lastDate   = user.last_activity_date as string | null;
  let streakCount  = (user.streak_count as number) ?? 0;
  let restDayUsed  = (user.rest_day_used as boolean) ?? false;
  let streakStatus = (user.streak_status as string) ?? "active";
  let frozenAt     = user.streak_frozen_at as string | null;
  let bonusPoints  = 0;
  let action: StreakAction = "active";

  // Already logged today — no update
  if (lastDate === today) {
    return { streakCount, streakStatus, restDayUsed, message: null, bonusPoints: 0, action: "duplicate" };
  }

  // Check if frozen streak expired (> 3 days since freeze)
  if (streakStatus === "frozen" && frozenAt) {
    const daysSinceFroze = daysBetween(frozenAt, today);
    if (daysSinceFroze > 3) {
      streakCount  = 1;
      streakStatus = "broken";
      restDayUsed  = false;
      frozenAt     = null;
      action       = "broken";
    } else {
      // Still within recovery window, update date only
      await supabase.from("users").update({ last_activity_date: today }).eq("id", userId);
      return { streakCount, streakStatus, restDayUsed, message: MESSAGES.frozen, bonusPoints: 0, action: "frozen" };
    }
  } else if (!lastDate) {
    // First ever activity
    streakCount  = 1;
    streakStatus = "active";
    frozenAt     = null;
    action       = "first";
  } else {
    const daysDiff = daysBetween(lastDate, today);

    // Weekly rest day reset when entering a new ISO week
    if (getISOWeek(today) !== getISOWeek(lastDate)) {
      restDayUsed = false;
    }

    if (daysDiff === 1) {
      streakCount += 1;
      streakStatus = "active";
      frozenAt     = null;
      action       = "active";
    } else if (daysDiff === 2) {
      if (!restDayUsed) {
        restDayUsed  = true;
        streakCount += 1;
        streakStatus = "active";
        frozenAt     = null;
        action       = "rest_day";
      } else {
        streakStatus = "frozen";
        frozenAt     = frozenAt ?? today;
        action       = "frozen";
      }
    } else {
      streakStatus = "frozen";
      frozenAt     = frozenAt ?? today;
      action       = "frozen";
    }
  }

  // Milestone bonus at 7 days
  if (action !== "frozen" && action !== "broken" && streakCount === 7) {
    bonusPoints = 10;
  }

  // Pick message
  let message: string = MESSAGES[action] ?? "";
  if (MILESTONE_MESSAGES[streakCount] && action !== "frozen" && action !== "broken") {
    message = MILESTONE_MESSAGES[streakCount]!;
  }

  // Persist
  const updates: Record<string, unknown> = {
    streak_count:       streakCount,
    last_activity_date: today,
    rest_day_used:      restDayUsed,
    streak_status:      action === "broken" ? "active" : streakStatus,
    streak_frozen_at:   frozenAt,
  };

  if (bonusPoints > 0) {
    updates.total_points = ((user.total_points as number) ?? 0) + bonusPoints;
  }

  await supabase.from("users").update(updates).eq("id", userId);

  return {
    streakCount,
    streakStatus: action === "broken" ? "active" : streakStatus,
    restDayUsed,
    message: message || null,
    bonusPoints,
    action,
  };
}

export async function recoverStreak(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: SupabaseClient<any>,
  userId: string,
): Promise<{ success: boolean; error?: string; newTotal?: number }> {
  const RECOVERY_COST = 50;
  const today = new Date().toISOString().split("T")[0]!;

  const { data: user } = await supabase
    .from("users")
    .select("streak_count, streak_status, streak_frozen_at, total_points")
    .eq("id", userId)
    .single();

  if (!user) return { success: false, error: "User not found" };

  if (user.streak_status !== "frozen") return { success: false, error: "Streak is not frozen" };

  const frozenAt = user.streak_frozen_at as string | null;
  if (!frozenAt) return { success: false, error: "No freeze date found" };

  const daysSinceFroze = daysBetween(frozenAt, today);
  if (daysSinceFroze > 3) return { success: false, error: "Recovery window expired (3 days max)" };

  const currentPoints = (user.total_points as number) ?? 0;
  if (currentPoints < RECOVERY_COST) return { success: false, error: "Not enough points (need 50)" };

  const newTotal = currentPoints - RECOVERY_COST;

  await supabase.from("users").update({
    streak_status:    "active",
    streak_frozen_at: null,
    total_points:     newTotal,
  }).eq("id", userId);

  return { success: true, newTotal };
}

export function getStreakColor(status: string): string {
  if (status === "frozen")  return "#5fa8d3";
  if (status === "broken")  return "#E63946";
  return "#22c55e";
}

export function getStreakEmoji(status: string): string {
  if (status === "frozen") return "❄️";
  if (status === "broken") return "💥";
  return "🔥";
}

export function getDaysUntilExpiry(frozenAt: string | null): number | null {
  if (!frozenAt) return null;
  const today = new Date().toISOString().split("T")[0]!;
  const diff = daysBetween(frozenAt, today);
  return Math.max(0, 3 - diff);
}
