import { activityOptions } from "@/lib/constants";
import type { Database } from "@/types/database";

export type UserProfile = Database["public"]["Tables"]["users"]["Row"];
export type Activity = Database["public"]["Tables"]["activities"]["Row"];

export type StoryMilestone = {
  id: number;
  min: number;
  max: number;
  title: string;
  arc: string;
  conditions: string[];
  message: string;
};

export type StoryMonth = {
  id: number;
  title: string;
  min: number;
  max: number;
  unlocked: boolean;
};

export const milestones: StoryMilestone[] = [
  { id: 1, min: 0, max: 100, title: "The Spark", arc: "Romance Dawn", conditions: ["You feel different from everyone around you", "You refuse to accept an ordinary life", "You take your first step into the unknown"], message: "Your journey begins the moment you refuse to stay ordinary." },
  { id: 2, min: 100, max: 250, title: "The Sacrifice", arc: "Dawn Island", conditions: ["You experience loss or emotional pain", "You realize dreams come with a cost", "You define your reason to keep going"], message: "Without sacrifice, dreams are just wishes." },
  { id: 3, min: 250, max: 400, title: "First Ally", arc: "Shells Town", conditions: ["You meet someone strong and independent", "You choose trust over control", "You stop trying to do everything alone"], message: "A lone fighter survives. A leader builds." },
  { id: 4, min: 400, max: 550, title: "Different Minds", arc: "Orange Town", conditions: ["You meet people who don’t fully trust you", "You learn to work with different personalities", "You accept that not everyone thinks like you"], message: "Understanding people is stronger than controlling them." },
  { id: 5, min: 550, max: 700, title: "Respect Dreams", arc: "Orange Town", conditions: ["You protect something meaningful to someone else", "You begin to understand others’ struggles", "You start valuing dreams beyond your own"], message: "Dreams are sacred — yours and theirs." },
  { id: 6, min: 700, max: 850, title: "Build Your Crew", arc: "Syrup Village", conditions: ["You accept imperfect people into your circle", "You begin forming your team", "You create a sense of belonging"], message: "Perfection doesn’t build teams — belief does." },
  { id: 7, min: 850, max: 950, title: "Reality Check", arc: "Baratie", conditions: ["You witness a gap between you and true strength", "You realize how much you still need to grow", "You stay grounded instead of giving up"], message: "Knowing your weakness is the start of real strength." },
  { id: 8, min: 950, max: 1000, title: "The Captain", arc: "Baratie", conditions: ["You take responsibility for others", "You begin leading with intention", "You stand firm in your values"], message: "You are no longer starting — you are leading." },
  { id: 9, min: 1000, max: 1150, title: "Entering the Unknown", arc: "Reverse Mountain", conditions: ["You step into a completely new environment", "You lose comfort and predictability", "You move forward despite uncertainty"], message: "The real journey begins where comfort ends." },
  { id: 10, min: 1150, max: 1300, title: "Hidden Enemies", arc: "Whiskey Peak", conditions: ["You realize not everyone is on your side", "You face deception or hidden intentions", "You become more aware and cautious"], message: "Trust wisely. Not blindly." },
  { id: 11, min: 1300, max: 1450, title: "Strength vs Strength", arc: "Little Garden", conditions: ["You encounter stronger individuals", "You compare yourself and feel pressure", "You choose growth over ego"], message: "Strength is not proven by pride, but by endurance." },
  { id: 12, min: 1450, max: 1600, title: "Unbreakable Bonds", arc: "Drum Island", conditions: ["You go through hardship with your team", "You support each other through struggle", "Your trust becomes stronger"], message: "A real crew is forged in struggle, not comfort." },
  { id: 13, min: 1600, max: 1750, title: "Responsibility", arc: "Alabasta", conditions: ["You take responsibility for something bigger", "Others begin to depend on you", "Your purpose becomes clearer"], message: "Leadership begins when others depend on you." },
  { id: 14, min: 1750, max: 1900, title: "Facing Defeat", arc: "Alabasta", conditions: ["You face a major setback or loss", "You realize effort alone is not enough", "You are forced to rethink your approach"], message: "Defeat is not the end — it is the truth." },
  { id: 15, min: 1900, max: 2000, title: "Rise Again", arc: "Alabasta", conditions: ["You return stronger after failure", "You adapt and improve", "You refuse to stay down"], message: "The difference is not strength — it’s getting back up." },
  { id: 16, min: 2000, max: 2150, title: "Mocked Dreams", arc: "Jaya", conditions: ["People doubt or laugh at your vision", "You feel misunderstood or alone", "You hold onto your belief"], message: "Not everyone will see your vision — and that’s okay." },
  { id: 17, min: 2150, max: 2300, title: "Silent Proof", arc: "Jaya", conditions: ["You stop explaining yourself", "You focus on actions over words", "You gain quiet confidence"], message: "You don’t need to argue — just prove it." },
  { id: 18, min: 2300, max: 2450, title: "Facing the Impossible", arc: "Skypiea", conditions: ["You confront something overwhelming", "You feel fear but move forward anyway", "You challenge your limits"], message: "Impossible is just something you haven’t faced yet." },
  { id: 19, min: 2450, max: 2600, title: "Purpose Beyond You", arc: "Skypiea", conditions: ["Your actions begin to impact others", "You carry responsibility beyond yourself", "Your purpose becomes deeper"], message: "Real strength is when others depend on you." },
  { id: 20, min: 2600, max: 2700, title: "Protect Your Crew", arc: "Long Ring Long Land", conditions: ["You almost lose something important", "You realize the value of your people", "You commit to protecting them"], message: "Your crew is your greatest treasure." },
  { id: 21, min: 2700, max: 2850, title: "The Breaking Point", arc: "Water 7", conditions: ["You face loss of something important", "Internal conflict creates tension within your team", "You begin to doubt your decisions"], message: "Leadership is tested when everything starts falling apart." },
  { id: 22, min: 2850, max: 2950, title: "Stand Alone", arc: "Water 7", conditions: ["You make decisions others don’t agree with", "You carry responsibility without support", "You stay true to your path"], message: "Sometimes the right path is the loneliest one." },
  { id: 23, min: 2950, max: 3000, title: "Declare Your Stand", arc: "Enies Lobby", conditions: ["You decide what truly matters to you", "You are ready to face any opposition", "You stand firm without hesitation"], message: "If it matters enough — you fight for it." },
];

export const months: StoryMonth[] = [
  { id: 1, title: "THE AWAKENING SEA", min: 0, max: 1000, unlocked: true },
  { id: 2, title: "THE DESERT OF TRIALS", min: 1000, max: 2000, unlocked: false },
  { id: 3, title: "THE SKY OF BELIEF", min: 2000, max: 3000, unlocked: false },
];

export function getCurrentMilestone(points: number) {
  return milestones.find((milestone) => points >= milestone.min && points < milestone.max) || milestones[milestones.length - 1];
}

export function getNextMilestone(points: number) {
  return milestones.find((milestone) => milestone.min > points) ?? null;
}

export function getUnlockedMonths(points: number) {
  return months.map((month) => ({
    ...month,
    unlocked: month.id === 1 || (month.id === 2 && points >= 1000) || (month.id === 3 && points >= 2000),
  }));
}

export function getCurrentMonth(points: number) {
  return months.find((month) => points >= month.min && points < month.max) || months[2];
}

export function getMonthMilestones(monthId: number) {
  const month = months.find((entry) => entry.id === monthId);
  if (!month) {
    return [];
  }
  return milestones.filter((milestone) => milestone.min >= month.min && milestone.max <= month.max);
}

export function getProgressPercent(points: number) {
  const current = getCurrentMilestone(points);
  const span = current.max - current.min;

  if (span <= 0) {
    return 100;
  }

  return Math.max(0, Math.min(100, Math.round(((points - current.min) / span) * 100)));
}

export function getActivityMeta(activityType: string) {
  return activityOptions.find((option) => option.value === activityType);
}
