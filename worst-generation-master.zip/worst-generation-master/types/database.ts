export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  public: {
    Tables: {
      reactions: {
        Row: {
          id: string;
          activity_id: string;
          user_id: string;
          emoji: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          activity_id: string;
          user_id: string;
          emoji: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          activity_id?: string;
          user_id?: string;
          emoji?: string;
          created_at?: string;
        };
      };
      activities: {
        Row: {
          activity_type: string;
          created_at: string;
          distance_km: number | null;
          duration_min: number | null;
          id: string;
          points: number;
          reps: number | null;
          user_id: string;
        };
        Insert: {
          activity_type: string;
          created_at?: string;
          distance_km?: number | null;
          duration_min?: number | null;
          id?: string;
          points?: number;
          reps?: number | null;
          user_id: string;
        };
        Update: {
          activity_type?: string;
          created_at?: string;
          distance_km?: number | null;
          duration_min?: number | null;
          id?: string;
          points?: number;
          reps?: number | null;
          user_id?: string;
        };
      };
      milestones: {
        Row: {
          id: number;
          name: string;
          points_required: number;
          title: string;
        };
        Insert: {
          id: number;
          name: string;
          points_required: number;
          title: string;
        };
        Update: {
          id?: number;
          name?: string;
          points_required?: number;
          title?: string;
        };
      };
      users: {
        Row: {
          avatar_url: string | null;
          created_at: string;
          email: string;
          id: string;
          name: string;
          total_points: number;
        };
        Insert: {
          avatar_url?: string | null;
          created_at?: string;
          email: string;
          id: string;
          name: string;
          total_points?: number;
        };
        Update: {
          avatar_url?: string | null;
          created_at?: string;
          email?: string;
          id?: string;
          name?: string;
          total_points?: number;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      log_activity: {
        Args: {
          p_activity_type: string;
          p_distance_km?: number | null;
          p_duration_min?: number | null;
          p_reps?: number | null;
          p_user_id: string;
        };
        Returns: {
          activity_id: string;
          awarded_points: number;
          new_total_points: number;
        }[];
      };
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};
