import { NextResponse } from "next/server";

import { createClient } from "@/lib/supabase/server";
import { recoverStreak } from "@/lib/streak";

export async function POST() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const result = await recoverStreak(supabase, user.id);

  if (!result.success) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }

  return NextResponse.json({ success: true, newTotal: result.newTotal });
}
