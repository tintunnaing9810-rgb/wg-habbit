import { NextResponse } from "next/server";

import { createClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = await createClient();

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const { data, error } = await supabase
    .from("activities")
    .select("id, activity_type, points, distance_km, duration_min, reps, created_at, user_id, users(name), reactions(emoji, user_id)")
    .gte("created_at", today.toISOString())
    .order("created_at", { ascending: false })
    .limit(50);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  return NextResponse.json({ activities: data ?? [] });
}
