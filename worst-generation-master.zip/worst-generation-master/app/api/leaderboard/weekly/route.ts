import { NextResponse } from "next/server";
import { startOfWeek } from "date-fns";

import { createClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = await createClient();

  const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });

  const [{ data: users }, { data: activities }] = await Promise.all([
    supabase.from("users").select("id, name, avatar_url, total_points, streak_count, streak_status"),
    supabase.from("activities").select("user_id, points").gte("created_at", weekStart.toISOString()),
  ]);

  const pointsMap = (activities ?? []).reduce<Record<string, number>>((acc, a) => {
    acc[a.user_id] = (acc[a.user_id] ?? 0) + a.points;
    return acc;
  }, {});

  const result = (users ?? [])
    .map(u => ({ ...u, weekly_points: pointsMap[u.id] ?? 0 }))
    .sort((a, b) => b.weekly_points - a.weekly_points);

  return NextResponse.json({ users: result });
}
