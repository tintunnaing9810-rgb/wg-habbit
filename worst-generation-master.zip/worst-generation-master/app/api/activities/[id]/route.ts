import { NextResponse } from "next/server";

import { createClient } from "@/lib/supabase/server";

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  // Fetch the activity to verify ownership and get points value
  const { data: activity, error: fetchError } = await supabase
    .from("activities")
    .select("id, points, user_id")
    .eq("id", id)
    .single();

  if (fetchError || !activity) {
    return NextResponse.json({ error: "Activity not found" }, { status: 404 });
  }

  if (activity.user_id !== user.id) {
    return NextResponse.json({ error: "Not your activity" }, { status: 403 });
  }

  // Delete the activity
  const { error: deleteError } = await supabase
    .from("activities")
    .delete()
    .eq("id", id);

  if (deleteError) {
    return NextResponse.json({ error: deleteError.message }, { status: 400 });
  }

  // Recalculate total points from remaining activities
  const { data: remaining } = await supabase
    .from("activities")
    .select("points")
    .eq("user_id", user.id);

  const newTotal = (remaining ?? []).reduce((sum, a) => sum + (a.points ?? 0), 0);

  await supabase
    .from("users")
    .update({ total_points: newTotal })
    .eq("id", user.id);

  return NextResponse.json({ success: true, newTotal });
}
