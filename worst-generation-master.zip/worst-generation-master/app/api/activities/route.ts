import { NextResponse } from "next/server";
import { z } from "zod";

import { createClient } from "@/lib/supabase/server";
import { updateStreak } from "@/lib/streak";

const schema = z
  .object({
    activityType: z.string().min(1),
    distanceKm: z.number().positive().nullable().optional(),
    durationMin: z.number().int().positive().nullable().optional(),
    reps: z.number().int().positive().nullable().optional(),
  })
  .superRefine((value, ctx) => {
    const distanceActivities = ["Running", "Walking"];
    const durationActivities = ["Gym", "Muay Thai", "Futsal", "Badminton", "Plank", "Swimming", "Golf"];
    const repsActivities     = ["Push-ups", "Pull ups", "Sit Ups", "Abs Workout", "Male Kegel"];
    const noneActivities     = ["Stretch", "3L Water"];

    if (distanceActivities.includes(value.activityType) && !value.distanceKm) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["distanceKm"],
        message: "Distance is required for this activity.",
      });
    }

    if (distanceActivities.includes(value.activityType) && (value.durationMin || value.reps)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["activityType"],
        message: "Only the distance field is allowed for this activity.",
      });
    }

    if (durationActivities.includes(value.activityType) && !value.durationMin) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["durationMin"],
        message: "Duration is required for this activity.",
      });
    }

    if (durationActivities.includes(value.activityType) && (value.distanceKm || value.reps)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["activityType"],
        message: "Only the duration field is allowed for this activity.",
      });
    }

    if (repsActivities.includes(value.activityType) && !value.reps) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["reps"],
        message: "Reps are required for this activity.",
      });
    }

    if (repsActivities.includes(value.activityType) && (value.distanceKm || value.durationMin)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["activityType"],
        message: "Only the reps field is allowed for this activity.",
      });
    }

    if (noneActivities.includes(value.activityType) && (value.distanceKm || value.durationMin || value.reps)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["activityType"],
        message: "This activity requires no data.",
      });
    }
  });

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const parsed = schema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { activityType, distanceKm, durationMin, reps } = parsed.data;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Stretch: only allowed if user has another activity logged today
  if (activityType === "Stretch") {
    const { data: todayActivities } = await supabase
      .from("activities")
      .select("id")
      .eq("user_id", user.id)
      .gte("created_at", today.toISOString())
      .neq("activity_type", "Stretch")
      .limit(1);

    if (!todayActivities || todayActivities.length === 0) {
      return NextResponse.json(
        { error: "You can only log Stretch after completing another activity today." },
        { status: 400 },
      );
    }
  }

  // 3L Water: once per day only
  if (activityType === "3L Water") {
    const { data: alreadyLogged } = await supabase
      .from("activities")
      .select("id")
      .eq("user_id", user.id)
      .eq("activity_type", "3L Water")
      .gte("created_at", today.toISOString())
      .limit(1);

    if (alreadyLogged && alreadyLogged.length > 0) {
      return NextResponse.json(
        { error: "You can only log 3L Water once per day." },
        { status: 400 },
      );
    }
  }

  // @ts-expect-error -- Supabase RPC generic type inference mismatch
  const { data, error } = await supabase.rpc("log_activity", {
    p_activity_type: activityType,
    p_distance_km: distanceKm ?? null,
    p_duration_min: durationMin ?? null,
    p_reps: reps ?? null,
    p_user_id: user.id,
  });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  const streak = await updateStreak(supabase, user.id);

  return NextResponse.json({ activity: data?.[0] ?? null, streak }, { status: 201 });
}
