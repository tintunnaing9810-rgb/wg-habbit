import { NextResponse } from "next/server";
import { z } from "zod";

import { createClient } from "@/lib/supabase/server";

const schema = z.object({
  activity_id: z.string().uuid(),
  emoji: z.enum(["🔥", "💪", "⚡", "👊"]),
});

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid" }, { status: 400 });

  const { activity_id, emoji } = parsed.data;

  // Toggle: delete if exists, insert if not
  const { data: existing } = await supabase
    .from("reactions")
    .select("id")
    .eq("activity_id", activity_id)
    .eq("user_id", user.id)
    .eq("emoji", emoji)
    .maybeSingle();

  if (existing) {
    await supabase.from("reactions").delete().eq("id", existing.id);
    return NextResponse.json({ action: "removed" });
  }

  await supabase.from("reactions").insert({ activity_id, user_id: user.id, emoji });
  return NextResponse.json({ action: "added" });
}
