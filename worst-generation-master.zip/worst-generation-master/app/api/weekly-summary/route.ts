import { NextResponse } from "next/server";
import { startOfWeek } from "date-fns";

import { createClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });

  const { data } = await supabase
    .from("activities")
    .select("activity_type, points, distance_km, duration_min, reps")
    .eq("user_id", user.id)
    .gte("created_at", weekStart.toISOString());

  return NextResponse.json({ activities: data ?? [] });
}
