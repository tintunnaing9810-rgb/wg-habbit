import { PageHeader } from "@/components/page-header";
import { RealtimeLeaderboard } from "@/components/realtime-leaderboard";
import { requireUser } from "@/lib/auth";

export default async function LeaderboardPage() {
  const { supabase } = await requireUser();
  const { data: users } = await supabase.from("users").select("*, streak_count, streak_status").order("total_points", { ascending: false });

  if (!users) {
    return null;
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Crew standings"
        title="Leaderboard"
      />
      <RealtimeLeaderboard initialUsers={users} />
    </div>
  );
}
