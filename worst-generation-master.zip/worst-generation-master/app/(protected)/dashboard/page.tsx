import { Anchor, Sparkles } from "lucide-react";

import { DashboardStats } from "@/components/dashboard-stats";
import { RecentActivities } from "@/components/recent-activities";
import { StreakDisplay } from "@/components/streak-display";
import { WantedPoster } from "@/components/wanted-poster";
import { WeeklySummary } from "@/components/weekly-summary";
import { requireUser } from "@/lib/auth";
import { getCurrentMilestone, getCurrentMonth, getNextMilestone, getProgressPercent, type UserProfile } from "@/lib/progression";
import { formatPoints } from "@/lib/utils";

export default async function DashboardPage() {
  const { supabase, user } = await requireUser();

  const { data: profileRaw } = await supabase.from("users").select("*, streak_count, last_activity_date, rest_day_used, streak_status, streak_frozen_at").eq("id", user.id).single();
  const profile = profileRaw as UserProfile | null;
  const { data: activities } = await supabase.from("activities").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(5);

  if (!profile) return null;

  const currentMilestone = getCurrentMilestone(profile.total_points);
  const currentMonth     = getCurrentMonth(profile.total_points);
  const nextMilestone    = getNextMilestone(profile.total_points);
  const progressPercent  = getProgressPercent(profile.total_points);

  return (
    <div className="space-y-5">
      <WantedPoster
        userId={user.id}
        name={profile.name}
        totalPoints={profile.total_points}
        avatarUrl={(profile as Record<string, unknown>).avatar_url as string | null ?? null}
      />

      <DashboardStats
        totalPoints={profile.total_points}
        currentTitle={currentMilestone.title}
        currentArc={currentMilestone.arc}
        nextMilestone={nextMilestone?.title ?? "Declare Your Stand"}
        nextMilestonePoints={nextMilestone?.min ?? profile.total_points}
        progressPercent={progressPercent}
      />

      <WeeklySummary />

      {/* Streak card */}
      <StreakDisplay
        streakCount={(profile as Record<string, unknown>).streak_count as number ?? 0}
        streakStatus={(profile as Record<string, unknown>).streak_status as string ?? "active"}
        restDayUsed={(profile as Record<string, unknown>).rest_day_used as boolean ?? false}
        frozenAt={(profile as Record<string, unknown>).streak_frozen_at as string | null ?? null}
        totalPoints={profile.total_points}
      />

      <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">

        {/* Current chapter card */}
        <section className="rounded-[12px] p-6" style={{ background: "#111111", border: "1px solid rgba(244,162,97,0.2)" }}>
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="label-caps">Chapter {currentMonth.id}</p>
              <h2 className="mt-1 text-2xl font-black uppercase tracking-[0.06em]" style={{ color: "#F1FAEE" }}>{currentMonth.title}</h2>
              <p className="mt-1 text-xs" style={{ color: "rgba(241,250,238,0.35)" }}>
                {formatPoints(currentMonth.min)} – {formatPoints(currentMonth.max)} pts
              </p>
            </div>
            <span className="inline-flex shrink-0 items-center gap-1.5 rounded-[4px] px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider"
              style={{ background: "rgba(230,57,70,0.12)", color: "#E63946", border: "1px solid rgba(230,57,70,0.3)" }}>
              <Anchor className="h-3 w-3" /> In Progress
            </span>
          </div>

          <div className="my-5 h-px" style={{ background: "rgba(244,162,97,0.15)" }} />

          <p className="label-caps" style={{ color: "rgba(244,162,97,0.6)" }}>✦ &nbsp;{currentMilestone.arc}</p>
          <div className="mt-2 flex items-center justify-between gap-3 flex-wrap">
            <h3 className="text-xl font-black uppercase tracking-[0.05em]" style={{ color: "#F1FAEE" }}>{currentMilestone.title}</h3>
            <span className="shrink-0 rounded-[6px] px-3 py-1 text-xs font-bold" style={{ background: "rgba(244,162,97,0.12)", color: "#F4A261", border: "1px solid rgba(244,162,97,0.25)" }}>
              {formatPoints(currentMilestone.min)} – {formatPoints(currentMilestone.max)} pts
            </span>
          </div>

          {/* Milestone progress bar */}
          {(() => {
            const range = currentMilestone.max - currentMilestone.min;
            const earned = Math.min(profile.total_points - currentMilestone.min, range);
            const pct = range > 0 ? Math.round((earned / range) * 100) : 100;
            return (
              <div className="mt-3">
                <div className="h-1.5 w-full rounded-full overflow-hidden" style={{ background: "rgba(241,250,238,0.07)" }}>
                  <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: "linear-gradient(90deg, #F4A261, #E63946)" }} />
                </div>
              </div>
            );
          })()}

          <p className="mt-3 text-sm leading-6 italic" style={{ color: "rgba(241,250,238,0.5)" }}>
            &ldquo;{currentMilestone.message}&rdquo;
          </p>

          <ul className="mt-5 grid gap-2">
            {currentMilestone.conditions.map((condition) => (
              <li
                key={condition}
                className="flex items-start gap-3 rounded-[6px] px-4 py-3 text-sm"
                style={{ background: "rgba(241,250,238,0.04)", border: "1px solid rgba(241,250,238,0.07)", color: "rgba(241,250,238,0.65)" }}
              >
                <span className="mt-px shrink-0 text-xs" style={{ color: "#F4A261" }}>✦</span>
                {condition}
              </li>
            ))}
          </ul>
        </section>

        {/* Recent activities */}
        <section className="rounded-[12px] p-6" style={{ background: "#111111", border: "1px solid rgba(241,250,238,0.08)" }}>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-[8px]" style={{ background: "rgba(230,57,70,0.15)" }}>
              <Sparkles className="h-5 w-5" style={{ color: "#E63946" }} />
            </div>
            <div>
              <p className="label-caps">Training Log</p>
              <h2 className="text-base font-bold" style={{ color: "#F1FAEE" }}>Latest Sessions</h2>
            </div>
          </div>
          <RecentActivities activities={activities ?? []} />
        </section>

      </div>
    </div>
  );
}
