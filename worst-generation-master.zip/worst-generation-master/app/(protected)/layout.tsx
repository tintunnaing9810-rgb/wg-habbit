import { TopBar } from "@/components/top-bar";

export default function ProtectedLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <>
      <TopBar />
      <main className="mx-auto min-h-screen max-w-5xl px-4 pb-10 pt-24 md:px-6 md:pt-24">
        {children}
      </main>
    </>
  );
}
