import { Anchor, Lock, Ship } from "lucide-react";

import { PageHeader } from "@/components/page-header";
import { requireUser } from "@/lib/auth";
import { getCurrentMonth, getCurrentMilestone, getMonthMilestones, getUnlockedMonths, type UserProfile } from "@/lib/progression";
import { cn, formatPoints } from "@/lib/utils";

const ISLAND_ICONS = ["⚓", "🏜️", "☁️"];
const ISLAND_COLORS = [
  { border: "border-surf/25", glow: "shadow-[0_0_40px_rgba(95,168,211,0.1)]", accent: "text-surf", node: "bg-surf/20 border-surf/40", active: "bg-gold border-gold text-ink", connector: "bg-gradient-to-b from-surf/40 to-white/5" },
  { border: "border-gold/25", glow: "shadow-[0_0_40px_rgba(216,164,55,0.1)]", accent: "text-gold", node: "bg-gold/20 border-gold/40", active: "bg-gold border-gold text-ink", connector: "bg-gradient-to-b from-gold/40 to-white/5" },
  { border: "border-coral/20", glow: "shadow-[0_0_40px_rgba(231,111,81,0.08)]", accent: "text-coral", node: "bg-coral/20 border-coral/40", active: "bg-gold border-gold text-ink", connector: "bg-gradient-to-b from-coral/40 to-white/5" },
];

export default async function ProgressPage() {
  const { supabase, user } = await requireUser();
  const { data: profileRaw } = await supabase.from("users").select("*").eq("id", user.id).single();
  const profile = profileRaw as UserProfile | null;

  if (!profile) return null;

  const unlockedMonths = getUnlockedMonths(profile.total_points);
  const currentMonth = getCurrentMonth(profile.total_points);
  const currentMilestone = getCurrentMilestone(profile.total_points);

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Grand Line milestones"
        title="Treasure Map"
        description={`Currently sailing: ${currentMonth.title}. You hold the rank of ${currentMilestone.title}.`}
      />

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-white/6 bg-white/3 px-5 py-3 text-xs text-white/40">
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full bg-gold" />
          Current position
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full border border-white/25 bg-white/8" />
          Completed
        </div>
        <div className="flex items-center gap-2">
          <div className="h-3 w-3 rounded-full border border-white/8 bg-white/3" />
          Not yet reached
        </div>
        <div className="flex items-center gap-2">
          <Lock className="h-3 w-3" />
          Locked chapter
        </div>
      </div>

      {/* Islands / Chapters */}
      <div className="grid gap-5">
        {unlockedMonths.map((month, monthIndex) => {
          const milestones = getMonthMilestones(month.id);
          const colors = ISLAND_COLORS[monthIndex] ?? ISLAND_COLORS[0]!;
          const isCurrentMonth = month.id === currentMonth.id;
          const completedMonth = profile.total_points >= month.max;

          return (
            <article
              key={month.id}
              className={cn(
                "relative overflow-hidden rounded-[1.75rem] border transition-all",
                month.unlocked
                  ? `game-card ${colors.border} ${colors.glow}`
                  : "game-card border-white/6",
              )}
            >
              {/* Chapter header */}
              <div className="flex items-center justify-between gap-4 border-b border-white/6 px-6 py-5">
                <div className="flex items-center gap-4">
                  <div
                    className={cn(
                      "flex h-12 w-12 items-center justify-center rounded-2xl text-2xl",
                      month.unlocked ? "bg-white/8" : "bg-white/3",
                    )}
                  >
                    {month.unlocked ? ISLAND_ICONS[monthIndex] ?? "🗺️" : "🔒"}
                  </div>
                  <div>
                    <p className={cn("text-[10px] font-black uppercase tracking-[0.25em]", month.unlocked ? colors.accent : "text-white/20")}>
                      Chapter {month.id}
                    </p>
                    <h2 className={cn("mt-0.5 font-[var(--font-display)] text-xl leading-tight", month.unlocked ? "text-white" : "text-white/25")}>
                      {month.title}
                    </h2>
                    <p className={cn("text-xs", month.unlocked ? "text-white/40" : "text-white/15")}>
                      {formatPoints(month.min)} – {formatPoints(month.max)} pts
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  {completedMonth ? (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-gold/15 px-3 py-1.5 text-xs font-bold text-gold">
                      <Ship className="h-3 w-3" /> Sailed Through
                    </span>
                  ) : isCurrentMonth ? (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-surf/15 px-3 py-1.5 text-xs font-bold text-surf">
                      <Anchor className="h-3 w-3" /> In Progress
                    </span>
                  ) : !month.unlocked ? (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/6 px-3 py-1.5 text-xs font-bold text-white/30">
                      <Lock className="h-3 w-3" /> {month.id === 2 ? "Unlock at 1,000 pts" : "Unlock at 2,000 pts"}
                    </span>
                  ) : null}
                </div>
              </div>

              {/* Milestones path — locked = fog overlay */}
              <div className="relative px-6 py-5">
                {!month.unlocked && (
                  <div className="fog-overlay z-10 flex flex-col items-center justify-center rounded-[1.25rem] gap-3 py-12">
                    <Lock className="h-10 w-10 text-white/20" />
                    <p className="text-sm font-semibold text-white/30">
                      Reach {month.id === 2 ? "1,000" : "2,000"} points to unlock
                    </p>
                  </div>
                )}

                <div className={cn("grid gap-0", !month.unlocked ? "pointer-events-none blur-sm select-none" : "")}>
                  {milestones.map((milestone, i) => {
                    const reached = profile.total_points >= milestone.min;
                    const isCurrent = profile.total_points >= milestone.min && profile.total_points < milestone.max;
                    const isLastInMonth = i === milestones.length - 1;

                    return (
                      <div key={milestone.id} className="flex gap-4">
                        {/* Path + node column */}
                        <div className="flex flex-col items-center">
                          <div
                            className={cn(
                              "relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 text-xs font-black transition-all",
                              isCurrent
                                ? `${colors.active} animate-gold-glow`
                                : reached
                                ? colors.node
                                : "border-white/8 bg-white/3 text-white/15",
                            )}
                          >
                            {isCurrent ? "✦" : reached ? "✓" : i + 1}
                          </div>
                          {!isLastInMonth && (
                            <div
                              className={cn(
                                "mt-1 flex-1 w-0.5",
                                reached ? colors.connector : "bg-white/5",
                              )}
                              style={{ minHeight: "1.5rem" }}
                            />
                          )}
                        </div>

                        {/* Milestone content */}
                        <div
                          className={cn(
                            "mb-3 flex-1 rounded-[1.25rem] border p-4 transition-all",
                            isCurrent
                              ? "border-gold/25 bg-gold/8 shadow-[0_0_20px_rgba(216,164,55,0.1)]"
                              : reached
                              ? "border-white/8 bg-white/4"
                              : "border-white/4 bg-white/2",
                          )}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0 flex-1">
                              <p className={cn("text-[10px] font-semibold uppercase tracking-widest", isCurrent ? "text-gold/70" : reached ? "text-white/30" : "text-white/15")}>
                                {milestone.arc}
                              </p>
                              <h3 className={cn("mt-0.5 text-sm font-bold leading-tight", isCurrent ? "text-white" : reached ? "text-white/70" : "text-white/25")}>
                                {milestone.title}
                              </h3>
                              {/* Point range — always visible */}
                              <p className={cn("mt-1 text-xs font-bold", isCurrent ? "text-gold" : reached ? "text-white/40" : "text-white/20")}>
                                {formatPoints(milestone.min)} – {formatPoints(milestone.max)} pts
                              </p>
                              {isCurrent && (
                                <>
                                  <p className="mt-2 text-xs leading-5 text-white/50">{milestone.message}</p>
                                  <ul className="mt-3 grid gap-1.5">
                                    {milestone.conditions.map((c) => (
                                      <li key={c} className="flex items-start gap-1.5 text-xs text-white/40">
                                        <span className="mt-px shrink-0 text-gold text-[10px]">✦</span>
                                        {c}
                                      </li>
                                    ))}
                                  </ul>
                                </>
                              )}
                            </div>
                            <div className={cn("shrink-0 rounded-xl px-2.5 py-1 text-xs font-black whitespace-nowrap", isCurrent ? "bg-gold/20 text-gold" : reached ? "bg-white/8 text-white/40" : "bg-white/3 text-white/15")}>
                              {isCurrent ? "✦ Current" : reached ? "✓" : `#${milestone.id}`}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Sea crossing between islands */}
              {monthIndex < unlockedMonths.length - 1 && month.unlocked && (
                <div className="flex items-center justify-center gap-3 border-t border-white/6 py-4 text-xs text-white/20">
                  <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                  <span>~~ sailing to the next island ~~</span>
                  <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                </div>
              )}
            </article>
          );
        })}
      </div>
    </div>
  );
}
