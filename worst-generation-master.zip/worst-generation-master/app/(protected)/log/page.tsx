import { LogActivityForm } from "@/components/log-activity-form";
import { CrewLogFeed } from "@/components/crew-log-feed";
import { PageHeader } from "@/components/page-header";
import { PointFormulaInfo } from "@/components/point-formula-info";
import { requireUser } from "@/lib/auth";

export default async function LogPage() {
  const { supabase, user } = await requireUser();
  const { data: profileRaw } = await supabase.from("users").select("total_points").eq("id", user.id).single();
  const profile = profileRaw as { total_points: number } | null;

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Ship's logbook"
        title="Record an Activity"
        description="Write your training into the ship's log. Your bounty will be calculated and updated across the fleet."
      />

      <div className="grid gap-5 lg:grid-cols-2">
        <LogActivityForm totalPoints={profile?.total_points ?? 0} />
        <div className="space-y-5">
          <CrewLogFeed currentUserId={user.id} />
          <PointFormulaInfo />
        </div>
      </div>
    </div>
  );
}
