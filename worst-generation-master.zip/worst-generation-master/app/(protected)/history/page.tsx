import { format, parseISO } from "date-fns";
import { Dumbbell, Footprints, Shield, Waves, Zap } from "lucide-react";

import { requireUser } from "@/lib/auth";
import { PageHeader } from "@/components/page-header";
import { getActivityMeta } from "@/lib/progression";
import { formatPoints } from "@/lib/utils";

type ActivityRow = {
  id: string;
  activity_type: string;
  points: number;
  distance_km: number | null;
  duration_min: number | null;
  reps: number | null;
  created_at: string;
};

const ICON_MAP: Record<string, React.ElementType> = {
  Running: Footprints, Walking: Waves, Gym: Dumbbell, "Muay Thai": Shield,
  Futsal: Footprints, Badminton: Footprints, Plank: Dumbbell, Swimming: Waves,
  Golf: Footprints, "Male Kegel": Dumbbell, Stretch: Waves, "3L Water": Waves,
  "Push-ups": Zap, "Pull ups": Zap, "Sit Ups": Zap, "Abs Workout": Zap,
};

export default async function HistoryPage() {
  const { supabase, user } = await requireUser();

  const { data: activitiesRaw } = await supabase
    .from("activities")
    .select("id, activity_type, points, distance_km, duration_min, reps, created_at")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  const { data: profileRaw } = await supabase
    .from("users")
    .select("created_at")
    .eq("id", user.id)
    .single();

  const activities = (activitiesRaw ?? []) as ActivityRow[];
  const totalPoints = activities.reduce((sum, a) => sum + a.points, 0);

  const grouped = activities.reduce<Record<string, typeof activities>>((acc, activity) => {
    const day = format(parseISO(activity.created_at), "yyyy-MM-dd");
    (acc[day] ??= []).push(activity);
    return acc;
  }, {});

  const days = Object.keys(grouped).sort((a, b) => b.localeCompare(a));

  const profile = profileRaw as { created_at: string } | null;
  const memberSince = profile?.created_at
    ? format(parseISO(profile.created_at), "MMM d, yyyy")
    : "—";

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Battle Record"
        title="Training History"
        description="Every activity you've logged since joining the crew."
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Total Activities" value={String(activities.length)} />
        <StatCard label="Bounty Earned" value={`${formatPoints(totalPoints)} pts`} />
        <StatCard label="Active Days" value={String(days.length)} />
        <StatCard label="Crew Member Since" value={memberSince} small />
      </div>

      {activities.length === 0 ? (
        <div className="game-card rounded-[1.25rem] p-10 text-center">
          <p className="text-4xl">⚓</p>
          <p className="mt-3 text-sm" style={{ color: "rgba(241,250,238,0.35)" }}>
            No activities logged yet. Start training!
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {days.map((day) => {
            const dayActivities = grouped[day];
            const dayPoints = dayActivities.reduce((s, a) => s + a.points, 0);
            return (
              <div key={day} className="game-card rounded-[1.25rem] p-4">
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-sm font-bold" style={{ color: "#F1FAEE" }}>
                    {format(parseISO(day), "EEEE, MMMM d, yyyy")}
                  </p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs" style={{ color: "rgba(241,250,238,0.35)" }}>
                      {dayActivities.length} {dayActivities.length === 1 ? "activity" : "activities"}
                    </span>
                    <span className="text-sm font-bold" style={{ color: "#F4A261" }}>
                      +{formatPoints(dayPoints)} pts
                    </span>
                  </div>
                </div>
                <div className="grid gap-2">
                  {dayActivities.map((activity) => {
                    const meta = getActivityMeta(activity.activity_type);
                    const summary =
                      activity.distance_km !== null
                        ? `${activity.distance_km} km`
                        : activity.duration_min !== null
                          ? `${activity.duration_min} min`
                          : activity.reps !== null
                            ? `${activity.reps} reps`
                            : "—";
                    const Icon = ICON_MAP[activity.activity_type] ?? Dumbbell;
                    return (
                      <div
                        key={activity.id}
                        className="flex items-center gap-3 rounded-[8px] p-3"
                        style={{
                          background: "rgba(241,250,238,0.04)",
                          border: "1px solid rgba(241,250,238,0.07)",
                        }}
                      >
                        <div
                          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[6px]"
                          style={{ background: "rgba(230,57,70,0.15)" }}
                        >
                          <Icon className="h-4 w-4" style={{ color: "#E63946" }} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold" style={{ color: "#F1FAEE" }}>
                            {meta?.label ?? activity.activity_type}
                          </p>
                          <p className="text-xs" style={{ color: "rgba(241,250,238,0.4)" }}>
                            {summary}
                          </p>
                        </div>
                        <div className="shrink-0 text-right">
                          <p className="text-sm font-bold" style={{ color: "#F4A261" }}>
                            +{formatPoints(activity.points)}
                          </p>
                          <p className="text-[10px]" style={{ color: "rgba(241,250,238,0.25)" }}>
                            {format(parseISO(activity.created_at), "HH:mm")}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, small }: { label: string; value: string; small?: boolean }) {
  return (
    <div className="game-card rounded-[1.25rem] p-4">
      <p
        className="text-xs font-semibold uppercase tracking-widest"
        style={{ color: "rgba(241,250,238,0.35)" }}
      >
        {label}
      </p>
      <p
        className={`mt-2 font-black ${small ? "text-lg" : "text-2xl"}`}
        style={{ color: "#F1FAEE" }}
      >
        {value}
      </p>
    </div>
  );
}
