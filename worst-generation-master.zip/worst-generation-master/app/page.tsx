import Link from "next/link";
import { Anchor, Gem, Shield, Trophy } from "lucide-react";

export default function HomePage() {
  return (
    <main className="relative flex min-h-screen flex-col overflow-hidden" style={{ background: "#1D3557" }}>
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute -left-40 top-0 h-96 w-96 rounded-full blur-[120px]" style={{ background: "rgba(230,57,70,0.08)" }} />
        <div className="absolute right-0 bottom-0 h-96 w-96 rounded-full blur-[120px]" style={{ background: "rgba(244,162,97,0.07)" }} />
      </div>

      <div className="relative mx-auto flex w-full max-w-5xl flex-1 flex-col px-6 py-10">
        {/* Nav */}
        <nav className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-[8px]" style={{ background: "rgba(230,57,70,0.15)" }}>
              <Anchor className="h-5 w-5" style={{ color: "#E63946" }} />
            </div>
            <span className="text-base font-black uppercase tracking-[0.15em]" style={{ color: "#F1FAEE" }}>Worst Generation</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/login" className="btn-ghost">Log in</Link>
            <Link href="/signup" className="btn-primary">Join the Crew</Link>
          </div>
        </nav>

        {/* Hero */}
        <div className="flex flex-1 flex-col items-center justify-center py-16 text-center">
          <div className="inline-flex items-center gap-2 rounded-[4px] px-4 py-1.5 text-[10px] font-bold uppercase tracking-[0.2em] mb-8"
            style={{ background: "rgba(230,57,70,0.12)", color: "#E63946", border: "1px solid rgba(230,57,70,0.25)" }}>
            ⚡ One Piece-Inspired Fitness Tracking
          </div>

          <h1 className="max-w-3xl text-5xl font-black uppercase tracking-tight md:text-7xl" style={{ color: "#F1FAEE", lineHeight: 1.05 }}>
            Train Your Way Across the{" "}
            <span className="gold-shimmer-text">Grand Line</span>
          </h1>

          <p className="mt-6 max-w-xl text-base leading-7" style={{ color: "rgba(241,250,238,0.5)" }}>
            Log workouts. Earn bounty points. Unlock story arcs. Race your crew across pirate seas — island by island.
          </p>

          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row">
            <Link href="/signup" className="btn-primary text-base px-10 py-4">Set Sail — Join Free</Link>
            <Link href="/login" className="btn-ghost text-base px-10 py-4">Return to the Grand Line</Link>
          </div>
        </div>

        {/* Feature cards */}
        <div className="grid gap-4 pb-8 sm:grid-cols-3">
          {[
            { icon: Gem,    color: "#F4A261", title: "Bounty System",    desc: "Every run, gym session, and rep earns bounty points. Watch your wanted level rise." },
            { icon: Shield, color: "#E63946", title: "Island Adventures",desc: "Each month is a new island. Reach 1,000 points to sail to the next chapter." },
            { icon: Trophy, color: "#2A9D8F", title: "Crew Rivalries",   desc: "Live leaderboard tracks your crew&apos;s bounties in real time. Who claims the top spot?" },
          ].map(({ icon: Icon, color, title, desc }) => (
            <div key={title} className="rounded-[12px] p-6" style={{ background: "#111111", border: `1px solid ${color}25` }}>
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-[8px]" style={{ background: `${color}15` }}>
                <Icon className="h-5 w-5" style={{ color }} />
              </div>
              <h3 className="font-black uppercase tracking-wide text-sm" style={{ color: "#F1FAEE" }}>{title}</h3>
              <p className="mt-2 text-sm leading-6" style={{ color: "rgba(241,250,238,0.45)" }}>{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
